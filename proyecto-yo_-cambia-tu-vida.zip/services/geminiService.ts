
import { GoogleGenAI, Type } from "@google/genai";
import { UserGoals, Action, Kpi, LogEntry, UserState } from "../types";

const getAi = () => {
    if (!process.env.API_KEY) {
        throw new Error("API_KEY environment variable not set");
    }
    return new GoogleGenAI({ apiKey: process.env.API_KEY });
};

export const generatePersonalizedPlan = async (goals: UserGoals): Promise<{ positiveActions: Action[], negativeActions: Action[], kpis: Omit<Kpi, 'completed'>[] }> => {
    try {
        const ai = getAi();
        const prompt = `
            Actúa como un experto en desarrollo personal y gamificación. El usuario te proporcionará sus metas, motivaciones y expectativas. Tu tarea es crear un plan de juego personalizado para su "Proyecto YO".

            Basado en la siguiente información del usuario:
            Objetivo Principal: ${goals.objective}
            Motivación (¿Por qué?): ${goals.motivation}
            Expectativas (¿Qué espera lograr?): ${goals.expectation}

            Genera una respuesta en formato JSON que contenga TRES claves: "positiveActions", "negativeActions", y "kpis".

            1.  **positiveActions**: Crea entre 5 y 7 acciones positivas. Cada acción debe ser un objeto con "description" (string, una tarea específica y medible) y "xp" (number, entre 3 y 15). Estas acciones deben estar directamente relacionadas con el objetivo del usuario.
            2.  **negativeActions**: Crea entre 3 y 4 penalizaciones. Cada penalización debe ser un objeto con "description" (string, un mal hábito a evitar) y "xp" (number, un valor negativo entre -5 y -15). Estas deben ser los obstáculos más probables para el usuario.
            3.  **kpis**: Crea entre 4 y 6 KPIs (Indicadores Clave de Desempeño) semanales. Cada KPI debe ser un objeto con "area" (string, una categoría como 'Salud', 'Finanzas', 'Aprendizaje', etc.) y "indicator" (string, una meta semanal clara y concisa).

            Asegúrate de que el plan sea coherente, motivador y directamente aplicable a las metas del usuario. Habla en español.
        `;
        
        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: prompt,
            config: {
                responseMimeType: "application/json",
                responseSchema: {
                    type: Type.OBJECT,
                    properties: {
                        positiveActions: {
                            type: Type.ARRAY,
                            items: {
                                type: Type.OBJECT,
                                properties: {
                                    description: { type: Type.STRING },
                                    xp: { type: Type.INTEGER }
                                },
                                required: ['description', 'xp']
                            }
                        },
                        negativeActions: {
                            type: Type.ARRAY,
                            items: {
                                type: Type.OBJECT,
                                properties: {
                                    description: { type: Type.STRING },
                                    xp: { type: Type.INTEGER }
                                },
                                required: ['description', 'xp']
                            }
                        },
                        kpis: {
                            type: Type.ARRAY,
                            items: {
                                type: Type.OBJECT,
                                properties: {
                                    area: { type: Type.STRING },
                                    indicator: { type: Type.STRING }
                                },
                                required: ['area', 'indicator']
                            }
                        }
                    },
                    required: ['positiveActions', 'negativeActions', 'kpis']
                }
            }
        });

        const jsonString = response.text.trim();
        const plan = JSON.parse(jsonString);

        if (!plan.positiveActions || !plan.negativeActions || !plan.kpis) {
             throw new Error("Invalid JSON structure from Gemini API");
        }

        return plan;
    } catch (error) {
        console.error("Error calling Gemini API for plan generation:", error);
        throw new Error("Failed to generate personalized plan from Gemini.");
    }
};

export const getCoachingAdvice = async (topic: string): Promise<{ text: string, sources: any[] }> => {
  try {
    const ai = getAi();
    const prompt = `Actúa como un coach de vida experto. Un usuario te ha preguntado sobre el siguiente tema: "${topic}".
Utilizando tu conocimiento y la información más reciente de la web, proporciona un consejo claro, accionable y motivador. Estructura tu respuesta en párrafos cortos y fáciles de leer. Sé directo y empático. Habla en español.`;
    
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
      config: {
        tools: [{googleSearch: {}}],
      },
    });

    const text = response.text.trim();
    if (!text) {
        throw new Error("Empty response from Gemini API");
    }
    
    const sources = response.candidates?.[0]?.groundingMetadata?.groundingChunks || [];
    
    return { text, sources };
  } catch (error) {
    console.error("Error calling Gemini API:", error);
    throw new Error("Failed to fetch coaching advice from Gemini.");
  }
};

export const getCheckinSuggestions = async (goals: UserGoals): Promise<{ priorities: string; dailyGoal: string; miniMission: string; }> => {
    try {
        const ai = getAi();
        const prompt = `
            Actúa como un coach de vida conciso y motivador para el sistema "Proyecto YO". Basado en los objetivos a largo plazo del usuario, genera sugerencias para su check-in diario.

            Objetivos del Usuario:
            - Objetivo Principal: ${goals.objective}
            - Motivación: ${goals.motivation}
            - Expectativas: ${goals.expectation}

            Genera una respuesta JSON con TRES claves: "priorities", "dailyGoal", y "miniMission".
            - "priorities": Una string con 3 tareas clave para hoy, separadas por saltos de línea (\\n). Deben ser pasos pequeños y accionables hacia el objetivo principal.
            - "dailyGoal": Una string con una meta inspiradora y alcanzable para el día. Una sola frase.
            - "miniMission": Una string con una "mini misión" creativa y pequeña. Debe ser algo que rompa la rutina o refuerce un buen hábito de forma simbólica (ej: "Dedica 5 minutos a organizar tu espacio de trabajo", "Contacta a un colega para agradecerle algo").

            Sé breve y directo. Habla en español.
        `;

        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: prompt,
            config: {
                responseMimeType: "application/json",
                responseSchema: {
                    type: Type.OBJECT,
                    properties: {
                        priorities: { type: Type.STRING },
                        dailyGoal: { type: Type.STRING },
                        miniMission: { type: Type.STRING }
                    },
                    required: ['priorities', 'dailyGoal', 'miniMission']
                }
            }
        });

        const jsonString = response.text.trim();
        return JSON.parse(jsonString);

    } catch (error) {
        console.error("Error calling Gemini API for check-in suggestions:", error);
        throw new Error("Failed to generate check-in suggestions from Gemini.");
    }
};

export const analyzeSentiment = async (text: string): Promise<'POSITIVE' | 'NEUTRAL' | 'NEGATIVE'> => {
    try {
        const ai = getAi();
        const prompt = `Analiza el sentimiento del siguiente texto y clasifícalo como POSITIVE, NEUTRAL, o NEGATIVE. Responde solo con una de esas tres palabras. Texto: "${text}"`;
        const response = await ai.models.generateContent({ model: 'gemini-2.5-flash', contents: prompt });
        const sentiment = response.text.trim().toUpperCase();
        if (sentiment === 'POSITIVE' || sentiment === 'NEUTRAL' || sentiment === 'NEGATIVE') {
            return sentiment;
        }
        return 'NEUTRAL';
    } catch (error) {
        console.error("Error analyzing sentiment:", error);
        return 'NEUTRAL';
    }
};

export const generateProgressReport = async (userState: UserState, logEntries: LogEntry[]): Promise<string> => {
    try {
        const ai = getAi();
        const prompt = `
            Actúa como un coach de rendimiento y desarrollo personal para el sistema "Proyecto YO".
            Analiza los siguientes datos del usuario de los últimos ${logEntries.length} días y genera un informe de progreso conciso y útil en formato Markdown.

            **Datos del Usuario:**
            - **Objetivo Principal:** ${userState.userGoals.objective}
            - **XP Total:** ${userState.totalXp}
            - **XP Semanal:** ${userState.weeklyXp}
            - **Racha Actual:** ${userState.currentStreak} días

            **Registro de Días:**
            ${logEntries.map(entry => `
            - **Fecha:** ${new Date(entry.date).toLocaleDateString('es-ES')}
            - **XP del Día:** ${entry.dailyXp}
            - **Sentimiento:** ${entry.sentiment || 'No analizado'}
            - **Reflexión:** "${entry.reflection}"
            - **Meta Cumplida:** ${entry.checkin.dailyGoal}
            `).join('\n')}

            **Análisis a Realizar:**
            1.  **Resumen del Período:** Ofrece un párrafo corto resumiendo el rendimiento general.
            2.  **Victorias Clave:** Identifica 2-3 logros o momentos positivos destacados.
            3.  **Patrones Detectados:** Analiza los datos para encontrar tendencias. ¿Qué días son más productivos? ¿Hay alguna correlación entre ciertas metas y el sentimiento reportado?
            4.  **Sugerencias Estratégicas:** Basado en todo lo anterior, ofrece 2-3 sugerencias concretas y accionables para el próximo ciclo (semana/mes).

            Sé constructivo, motivador y directo. Utiliza encabezados en Markdown (ej: '### Victorias Clave'). Habla en español.
        `;
        const response = await ai.models.generateContent({ model: 'gemini-2.5-flash', contents: prompt });
        return response.text.trim();
    } catch (error) {
        console.error("Error generating progress report:", error);
        throw new Error("Failed to generate progress report from Gemini.");
    }
};

export const generateProactiveMessage = async (pattern: string, goals: UserGoals): Promise<string> => {
    try {
        const ai = getAi();
        let patternDescription = '';
        if (pattern === 'repeated_social_media_penalty') {
            patternDescription = 'ha estado luchando con el uso excesivo de las redes sociales últimamente.';
        } else {
            patternDescription = 'ha mostrado un patrón que podría ser un obstáculo.';
        }

        const prompt = `
            Actúa como un coach de IA empático y solidario en el sistema "Proyecto YO".
            Un usuario, cuyo objetivo principal es "${goals.objective}", ${patternDescription}
            
            Tu tarea es escribir un mensaje proactivo, corto (2-3 frases) y amable para mostrar en su dashboard.
            El tono debe ser de apoyo, no de regaño. El objetivo es que se sienta visto y animado a reflexionar.
            
            Ejemplo de buen tono: "He notado que [hábito] ha sido un desafío últimamente. Recuerda que cada día es una nueva oportunidad para intentarlo. ¿Te gustaría explorar algunas estrategias juntos?"
            
            No incluyas saludos como "Hola". Ve directo al punto de forma cálida. Habla en español.
        `;
        const response = await ai.models.generateContent({ model: 'gemini-2.5-flash', contents: prompt });
        return response.text.trim();
    } catch (error) {
        console.error("Error generating proactive message:", error);
        return "Parece que has estado enfrentando un desafío. Recuerda ser amable contigo mismo. Estoy aquí si necesitas hablar.";
    }
};