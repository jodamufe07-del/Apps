
import React from 'react';
import { ALL_ACHIEVEMENTS } from '../constants';
import { Achievement } from '../types';

interface AchievementsProps {
    unlockedAchievementIds: string[];
}

const achievementIcons: Record<string, React.ReactNode> = {
    first_step: <path strokeLinecap="round" strokeLinejoin="round" d="M12 11c0 3.517-1.009 6.789-2.756 9.352-1.748-2.563-2.756-5.835-2.756-9.352 0-4.632 2.223-8.412 4.908-10.128a.5.5 0 01.684 0C14.777 2.588 17 6.368 17 11z" />,
    centurion: <path strokeLinecap="round" strokeLinejoin="round" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />,
    streak_3: <path strokeLinecap="round" strokeLinejoin="round" d="M17.657 18.657A8 8 0 016.343 7.343S7 9 9 10c0-2 .5-5 2.986-7.014A8.003 8.003 0 0117.657 18.657z" />,
    streak_7: <path strokeLinecap="round" strokeLinejoin="round" d="M13 10V3L4 14h7v7l9-11h-7z" />,
    discipline_master: <path strokeLinecap="round" strokeLinejoin="round" d="M5 3v4M3 5h4M6 17v4m-2-2h4m5-16l2.286 6.857L21 12l-5.714 2.143L13 21l-2.286-6.857L5 12l5.714-2.143L13 3z" />,
    early_bird: <path strokeLinecap="round" strokeLinejoin="round" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />,
    xp_hoarder_1k: <path strokeLinecap="round" strokeLinejoin="round" d="M5 3a2 2 0 00-2 2v14a2 2 0 002 2h14a2 2 0 002-2V5a2 2 0 00-2-2H5zM5 11h14" />,
    planner: <path strokeLinecap="round" strokeLinejoin="round" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />,
};


const AchievementBadge: React.FC<{ achievement: Omit<Achievement, 'icon'>, isUnlocked: boolean }> = ({ achievement, isUnlocked }) => {
    const icon = achievementIcons[achievement.id] || <path strokeLinecap="round" strokeLinejoin="round" d="M12 6.25278C12 6.25278 6.25417 3 3 3C3 12.3583 6.25417 21 12 21C17.7458 21 21 12.3583 21 3C17.7458 3 12 6.25278 12 6.25278Z" />;
    
    return (
        <div className={`bg-brand-bg-light dark:bg-brand-bg p-4 rounded-lg flex flex-col items-center text-center transition-all duration-300 ${isUnlocked ? 'border border-brand-primary-light/50 dark:border-brand-primary/50' : 'opacity-50'}`}>
            <div className={`w-16 h-16 rounded-full flex items-center justify-center mb-3 ${isUnlocked ? 'bg-brand-primary-light/10 dark:bg-brand-primary/20 text-brand-primary-light dark:text-brand-primary' : 'bg-gray-200 dark:bg-brand-text-secondary/20 text-gray-500 dark:text-brand-text-secondary'}`}>
                <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
                    {icon}
                </svg>
            </div>
            <h4 className={`font-bold ${isUnlocked ? 'text-brand-text-primary-light dark:text-brand-text-primary' : 'text-brand-text-secondary-light dark:text-brand-text-secondary'}`}>{achievement.name}</h4>
            <p className="text-xs text-brand-text-secondary-light dark:text-brand-text-secondary mt-1">{achievement.description}</p>
        </div>
    );
};


const Achievements: React.FC<AchievementsProps> = ({ unlockedAchievementIds }) => {
    const unlockedSet = new Set(unlockedAchievementIds);
    const unlockedCount = unlockedSet.size;
    const totalCount = ALL_ACHIEVEMENTS.length;

    return (
        <div className="bg-brand-surface-light dark:bg-brand-surface rounded-xl p-6 shadow-lg">
            <div className="text-center mb-6">
                <h3 className="text-xl font-bold">Mis Logros</h3>
                <p className="text-brand-text-secondary-light dark:text-brand-text-secondary text-sm mt-1">
                    Has desbloqueado <span className="font-bold text-brand-accent-light dark:text-brand-accent">{unlockedCount}</span> de <span className="font-bold text-brand-text-primary-light dark:text-brand-text-primary">{totalCount}</span> logros.
                </p>
                <div className="w-full bg-brand-bg-light dark:bg-brand-bg rounded-full h-2.5 mt-3">
                    <div className="bg-brand-accent-light dark:bg-brand-accent h-2.5 rounded-full" style={{ width: `${(unlockedCount/totalCount)*100}%` }}></div>
                </div>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
                {ALL_ACHIEVEMENTS.map(ach => (
                    <AchievementBadge key={ach.id} achievement={ach} isUnlocked={unlockedSet.has(ach.id)} />
                ))}
            </div>
        </div>
    );
};

export default Achievements;