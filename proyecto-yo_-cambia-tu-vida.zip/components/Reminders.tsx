
import React, { useState, useEffect, useCallback } from 'react';
import { Reminder } from '../types';

interface RemindersProps {
    reminders: Reminder[];
    onAdd: (reminder: Omit<Reminder, 'id'>) => void;
    onDelete: (id: string) => void;
}

const initialDays = {
    monday: false, tuesday: false, wednesday: false, thursday: false,
    friday: false, saturday: false, sunday: false
};

// FIX: Replaced JSX.Element with React.ReactNode to resolve "Cannot find namespace 'JSX'" error.
const dayIcons: { key: keyof Reminder['days'], label: string, icon: React.ReactNode }[] = [
    { key: 'monday', label: 'L', icon: 'L' },
    { key: 'tuesday', label: 'M', icon: 'M' },
    { key: 'wednesday', label: 'X', icon: 'X' },
    { key: 'thursday', label: 'J', icon: 'J' },
    { key: 'friday', label: 'V', icon: 'V' },
    { key: 'saturday', label: 'S', icon: 'S' },
    { key: 'sunday', label: 'D', icon: 'D' },
];

const Reminders: React.FC<RemindersProps> = ({ reminders, onAdd, onDelete }) => {
    const [title, setTitle] = useState('');
    const [time, setTime] = useState('08:00');
    const [days, setDays] = useState(initialDays);
    const [notificationPermission, setNotificationPermission] = useState(Notification.permission);

    useEffect(() => {
        // No-op, permission request is now user-initiated
    }, []);

    const requestNotificationPermission = useCallback(() => {
        Notification.requestPermission().then(permission => {
            setNotificationPermission(permission);
        });
    }, []);

    const handleDayToggle = (day: keyof Reminder['days']) => {
        setDays(prev => ({ ...prev, [day]: !prev[day] }));
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (!title || !time || Object.values(days).every(d => !d)) {
            alert('Por favor completa todos los campos y selecciona al menos un día.');
            return;
        }
        if (notificationPermission !== 'granted') {
            alert('Por favor, habilita las notificaciones para crear recordatorios.');
            return;
        }
        onAdd({ title, time, days });
        setTitle('');
        setTime('08:00');
        setDays(initialDays);
    };
    
    const DayButton: React.FC<{ day: typeof dayIcons[0], isSelected: boolean, onClick: () => void }> = ({ day, isSelected, onClick }) => (
      <button 
        type="button" 
        onClick={onClick} 
        aria-label={day.label}
        className={`w-9 h-9 flex items-center justify-center rounded-full transition-colors font-bold text-sm ${isSelected ? 'bg-brand-primary-light dark:bg-brand-primary text-white' : 'bg-brand-surface-light dark:bg-brand-surface hover:bg-brand-primary-light/20 dark:hover:bg-brand-primary/20 text-brand-text-secondary-light dark:text-brand-text-secondary'}`}
      >
        {day.icon}
      </button>
    );


    const renderReminderList = () => {
        if (reminders.length === 0) {
            return <p className="text-center text-brand-text-secondary-light dark:text-brand-text-secondary italic mt-4">No tienes recordatorios activos.</p>;
        }
        return (
            <div className="space-y-3 mt-4 max-h-60 overflow-y-auto pr-2">
                {reminders.map(reminder => (
                    <div key={reminder.id} className="bg-brand-bg-light dark:bg-brand-bg p-3 rounded-lg flex justify-between items-center transition-all">
                        <div>
                            <p className="font-semibold text-brand-text-primary-light dark:text-brand-text-primary">{reminder.title}</p>
                            <p className="text-sm text-brand-accent-light dark:text-brand-accent">{reminder.time}</p>
                            <div className="flex space-x-1.5 mt-2">
                                {dayIcons.map(day => (
                                    <span key={day.key} className={`text-xs font-bold ${reminder.days[day.key] ? 'text-brand-text-primary-light dark:text-brand-text-primary' : 'text-brand-text-secondary-light/30 dark:text-brand-text-secondary/30'}`}>
                                        {day.label}
                                    </span>
                                ))}
                            </div>
                        </div>
                        <button onClick={() => onDelete(reminder.id)} className="text-red-500 hover:text-red-400 p-2 rounded-full hover:bg-red-500/10 transition-colors">
                            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                            </svg>
                        </button>
                    </div>
                ))}
            </div>
        );
    };

    return (
        <div className="bg-brand-surface-light dark:bg-brand-surface rounded-xl p-6 shadow-lg">
            <h3 className="text-xl font-bold mb-4 text-center">Gestor de Recordatorios</h3>
            
            {notificationPermission !== 'granted' && (
                <div className="bg-yellow-500/10 border border-yellow-700 text-yellow-800 dark:text-yellow-300 text-sm rounded-lg p-3 mb-4 text-center">
                    <p>Las notificaciones son necesarias para los recordatorios.</p>
                    {notificationPermission === 'denied' ? (
                        <p className="font-semibold mt-1">Debes habilitarlas en la configuración de tu navegador.</p>
                    ) : (
                        <button onClick={requestNotificationPermission} className="mt-2 bg-yellow-600 hover:bg-yellow-500 text-white font-bold py-1 px-3 rounded">
                            Habilitar Notificaciones
                        </button>
                    )}
                </div>
            )}

            <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                    <label htmlFor="title" className="block text-sm font-medium text-brand-text-secondary-light dark:text-brand-text-secondary mb-1">Título</label>
                    <input type="text" id="title" value={title} onChange={e => setTitle(e.target.value)} required placeholder="Ej: Meditar, Check-in..." className="w-full bg-brand-bg-light dark:bg-brand-bg rounded-md border-gray-300 dark:border-brand-surface focus:ring-brand-primary-light dark:focus:ring-brand-primary focus:border-brand-primary-light dark:focus:border-brand-primary text-sm p-2"/>
                </div>
                <div>
                    <label htmlFor="time" className="block text-sm font-medium text-brand-text-secondary-light dark:text-brand-text-secondary mb-1">Hora</label>
                    <input type="time" id="time" value={time} onChange={e => setTime(e.target.value)} required className="w-full bg-brand-bg-light dark:bg-brand-bg rounded-md border-gray-300 dark:border-brand-surface focus:ring-brand-primary-light dark:focus:ring-brand-primary focus:border-brand-primary-light dark:focus:border-brand-primary text-sm p-2"/>
                </div>
                <div>
                    <label className="block text-sm font-medium text-brand-text-secondary-light dark:text-brand-text-secondary mb-2">Frecuencia</label>
                    <div className="flex justify-around items-center bg-brand-bg-light dark:bg-brand-bg p-2 rounded-md">
                        {dayIcons.map(day => (
                            <DayButton key={day.key} day={day} isSelected={days[day.key]} onClick={() => handleDayToggle(day.key)} />
                        ))}
                    </div>
                </div>
                <button type="submit" className="w-full bg-brand-primary-light dark:bg-brand-primary hover:bg-brand-primary-light/80 dark:hover:bg-brand-primary/80 text-white font-bold py-2 px-4 rounded-lg transition-colors duration-300 flex items-center justify-center space-x-2">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                    <span>Añadir Recordatorio</span>
                </button>
            </form>
            
            <div className="mt-6">
                <h4 className="font-semibold text-center text-brand-text-secondary-light dark:text-brand-text-secondary">Recordatorios Activos</h4>
                {renderReminderList()}
            </div>
        </div>
    );
};

export default Reminders;