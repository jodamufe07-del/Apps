
import React, { useEffect } from 'react';

interface ToastProps {
  message: string;
  onClose: () => void;
}

const Toast: React.FC<ToastProps> = ({ message, onClose }) => {
  useEffect(() => {
    const timer = setTimeout(() => {
      onClose();
    }, 3000); // The toast will disappear after 3 seconds

    return () => {
      clearTimeout(timer);
    };
  }, [onClose]);

  return (
    <div 
      className="fixed bottom-20 sm:bottom-5 left-1/2 -translate-x-1/2 bg-brand-accent-light dark:bg-brand-accent text-brand-bg-light dark:text-brand-bg font-semibold py-2 px-6 rounded-full shadow-lg toast-enter"
      role="alert"
    >
      {message}
    </div>
  );
};

export default Toast;