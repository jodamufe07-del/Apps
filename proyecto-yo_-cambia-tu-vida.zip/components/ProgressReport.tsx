
import React, { useState } from 'react';
import { UserState, LogEntry } from '../types';
import { generateProgressReport } from '../services/geminiService';
import { marked } from 'marked';

interface ProgressReportProps {
    userState: UserState;
    logEntries: LogEntry[];
}

const ProgressReport: React.FC<ProgressReportProps> = ({ userState, logEntries }) => {
    const [report, setReport] = useState<string | null>(null);
    const [isLoading, setIsLoading] = useState(false);
    const [period, setPeriod] = useState<'7' | '30'>('7');

    const handleGenerateReport = async () => {
        setIsLoading(true);
        setReport(null);
        try {
            const days = parseInt(period, 10);
            const filteredLogs = logEntries.slice(0, days);
            if (filteredLogs.length === 0) {
                setReport("No hay suficientes datos para generar un informe para este período. ¡Completa algunos días primero!");
                return;
            }
            const generatedReport = await generateProgressReport(userState, filteredLogs);
            setReport(generatedReport);
        } catch (error) {
            console.error("Failed to generate report:", error);
            setReport("Hubo un error al generar tu informe. Por favor, inténtalo de nuevo.");
        } finally {
            setIsLoading(false);
        }
    };
    
    const reportHtml = report ? marked.parse(report) : '';

    return (
        <div className="bg-brand-surface-light dark:bg-brand-surface rounded-xl p-6 shadow-lg">
            <div className="text-center mb-6">
                <h3 className="text-xl font-bold text-brand-text-primary-light dark:text-brand-text-primary">Informe de Progreso IA</h3>
                <p className="text-brand-text-secondary-light dark:text-brand-text-secondary text-sm mt-1">Recibe un análisis detallado de tu rendimiento y sugerencias de tu Coach IA.</p>
            </div>

            <div className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-6">
                <div className="flex items-center p-1 rounded-lg bg-brand-bg-light dark:bg-brand-bg space-x-1">
                    <button 
                        onClick={() => setPeriod('7')}
                        className={`w-full py-2 px-4 rounded-md text-sm font-semibold transition-colors ${period === '7' ? 'bg-brand-primary-light dark:bg-brand-primary text-white shadow' : 'hover:bg-gray-200 dark:hover:bg-brand-surface'}`}
                    >
                        Últimos 7 Días
                    </button>
                    <button 
                        onClick={() => setPeriod('30')}
                        className={`w-full py-2 px-4 rounded-md text-sm font-semibold transition-colors ${period === '30' ? 'bg-brand-primary-light dark:bg-brand-primary text-white shadow' : 'hover:bg-gray-200 dark:hover:bg-brand-surface'}`}
                    >
                        Últimos 30 Días
                    </button>
                </div>
                 <button 
                    onClick={handleGenerateReport}
                    disabled={isLoading}
                    className="bg-brand-primary-light dark:bg-brand-primary hover:bg-brand-primary-light/80 dark:hover:bg-brand-primary/80 text-white font-bold py-2 px-6 rounded-lg transition-colors flex items-center justify-center disabled:bg-gray-400 dark:disabled:bg-gray-600"
                >
                    {isLoading && <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin mr-2"></div>}
                    {isLoading ? 'Analizando...' : 'Generar Informe'}
                </button>
            </div>

            <div className="bg-brand-bg-light dark:bg-brand-bg p-4 rounded-lg min-h-[200px]">
                {isLoading ? (
                    <div className="flex items-center justify-center h-full">
                        <p className="text-brand-text-secondary-light dark:text-brand-text-secondary">Tu Coach IA está analizando tus datos...</p>
                    </div>
                ) : report ? (
                     <div 
                        className="prose prose-sm dark:prose-invert max-w-none text-brand-text-primary-light dark:text-brand-text-primary"
                        dangerouslySetInnerHTML={{ __html: reportHtml }}
                    />
                ) : (
                    <div className="flex items-center justify-center h-full">
                        <p className="text-brand-text-secondary-light dark:text-brand-text-secondary text-center">Selecciona un período y genera tu informe para ver tu análisis personalizado.</p>
                    </div>
                )}
            </div>
        </div>
    );
};

export default ProgressReport;