
import React, { useState, useEffect, useRef } from 'react';
import { AppView } from '../types';

interface NavMenuProps {
  userName: string;
  userLevel: string;
  currentView: AppView;
  onNavigate: (view: AppView) => void;
  onWeekReset: () => void;
  onFullReset: () => void;
  onLogout: () => void;
}

const NavMenu: React.FC<NavMenuProps> = ({ userName, userLevel, currentView, onNavigate, onWeekReset, onFullReset, onLogout }) => {
  const [isOpen, setIsOpen] = useState(false);
  const menuRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  const handleNavigation = (view: AppView) => {
    onNavigate(view);
    setIsOpen(false);
  };

  const navItems: { view: AppView; label: string }[] = [
    { view: 'AI_GOALS', label: 'Objetivos IA' },
    { view: 'PROGRESS_REPORT', label: 'Informe de Progreso' },
    { view: 'PROGRESS_ANALYSIS', label: 'Análisis de Progreso' },
    { view: 'SKILL_TREE', label: 'Árbol de Habilidades'},
    { view: 'ACHIEVEMENTS', label: 'Logros' },
    { view: 'LOGBOOK', label: 'Historial Diario' },
    { view: 'CALENDAR', label: 'Calendario' },
    { view: 'REMINDERS', label: 'Recordatorios' },
    { view: 'COACH', label: 'IA Coach' },
  ];

  return (
    <div className="relative" ref={menuRef}>
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="flex items-center space-x-2 bg-brand-surface-light dark:bg-brand-surface p-2 rounded-lg shadow-md hover:bg-gray-200 dark:hover:bg-brand-primary/20 transition-colors"
        aria-label="Abrir menú de usuario"
        data-tutorial-id="top-menu-step"
      >
        <div className="w-8 h-8 rounded-full bg-brand-primary-light dark:bg-brand-primary flex items-center justify-center">
          <span className="text-md font-bold text-white">{userName.charAt(0).toUpperCase()}</span>
        </div>
        <svg xmlns="http://www.w3.org/2000/svg" className={`h-5 w-5 text-brand-text-secondary-light dark:text-brand-text-secondary transition-transform ${isOpen ? 'rotate-180' : ''}`} viewBox="0 0 20 20" fill="currentColor">
          <path fillRule="evenodd" d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" clipRule="evenodd" />
        </svg>
      </button>

      {isOpen && (
        <div className="absolute right-0 mt-2 w-72 bg-brand-surface-light dark:bg-brand-surface rounded-xl shadow-2xl z-10 border border-gray-200 dark:border-brand-primary/20">
          <div className="p-4 border-b border-gray-200 dark:border-brand-primary/20">
            <p className="font-bold text-brand-text-primary-light dark:text-brand-text-primary">{userName}</p>
            <p className="text-sm text-brand-accent-light dark:text-brand-accent">{userLevel}</p>
          </div>
          <nav className="p-2 max-h-60 overflow-y-auto">
            {navItems.map(item => (
                <button
                    key={item.view}
                    onClick={() => handleNavigation(item.view)}
                    className={`w-full text-left px-3 py-2 rounded-md text-sm font-medium transition-colors ${currentView === item.view ? 'bg-brand-primary-light/20 dark:bg-brand-primary/30 text-brand-text-primary-light dark:text-brand-text-primary' : 'text-brand-text-secondary-light dark:text-brand-text-secondary hover:bg-gray-100 dark:hover:bg-brand-bg hover:text-brand-text-primary-light dark:hover:text-brand-text-primary'}`}
                >
                    {item.label}
                </button>
            ))}
          </nav>
          <div className="p-2 border-t border-gray-200 dark:border-brand-primary/20 space-y-2">
            <button onClick={onWeekReset} className="w-full text-left px-3 py-2 rounded-md text-sm font-medium text-brand-text-secondary-light dark:text-brand-text-secondary hover:bg-brand-secondary-light/20 dark:hover:bg-brand-secondary/20 hover:text-brand-secondary-light dark:hover:text-brand-secondary">Reiniciar Semana</button>
            <button onClick={onFullReset} className="w-full text-left px-3 py-2 rounded-md text-sm font-medium text-brand-text-secondary-light dark:text-brand-text-secondary hover:bg-red-500/10 dark:hover:bg-red-800/20 hover:text-red-600 dark:hover:text-red-500">Reiniciar Progreso Total</button>
            <button onClick={onLogout} className="w-full text-left px-3 py-2 rounded-md text-sm font-medium text-brand-text-secondary-light dark:text-brand-text-secondary hover:bg-gray-500/10 dark:hover:bg-gray-600/20 hover:text-gray-600 dark:hover:text-gray-300">Cerrar Sesión</button>
          </div>
        </div>
      )}
    </div>
  );
};

export default NavMenu;