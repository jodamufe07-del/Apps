
import React from 'react';
import { UserGoals, Action, Kpi, AppView } from '../types';

interface AiGoalsProps {
    userGoals: UserGoals;
    plan: {
        positiveActions: Action[];
        negativeActions: Action[];
        kpis: Kpi[];
    };
    onNavigate: (view: AppView) => void;
}

const GoalCard: React.FC<{ title: string; content: string; icon: React.ReactNode }> = ({ title, content, icon }) => (
    <div className="bg-brand-bg-light dark:bg-brand-bg p-4 rounded-lg flex items-start gap-4">
        <div className="flex-shrink-0 w-10 h-10 bg-brand-primary-light/10 dark:bg-brand-primary/20 rounded-full flex items-center justify-center text-brand-primary-light dark:text-brand-primary">{icon}</div>
        <div>
            <h4 className="font-bold text-brand-text-primary-light dark:text-brand-text-primary">{title}</h4>
            <p className="text-sm text-brand-text-secondary-light dark:text-brand-text-secondary">{content}</p>
        </div>
    </div>
);

const PlanSection: React.FC<{ title: string; items: (Action | Kpi)[]; icon: React.ReactNode; onEdit: () => void; actionType?: 'positive' | 'negative' }> = ({ title, items, icon, onEdit, actionType }) => (
    <div className="bg-brand-bg-light dark:bg-brand-bg p-4 rounded-lg h-full flex flex-col">
        <div className="flex justify-between items-center mb-3">
            <h4 className={`font-bold text-brand-text-primary-light dark:text-brand-text-primary flex items-center gap-2 ${actionType === 'positive' ? 'text-green-600 dark:text-green-400' : actionType === 'negative' ? 'text-red-600 dark:text-red-400' : ''}`}>{icon} {title}</h4>
            <button onClick={onEdit} className="text-sm text-brand-accent-light dark:text-brand-accent hover:underline">Editar</button>
        </div>
        <ul className="space-y-2 text-sm text-brand-text-secondary-light dark:text-brand-text-secondary list-disc list-inside flex-grow">
            {items.map((item, index) => (
                <li key={index}>
                    {'indicator' in item ? item.indicator : item.description}
                    {'xp' in item && <span className={`text-xs font-mono ml-2 p-1 rounded ${item.xp > 0 ? 'bg-green-500/10 text-green-700 dark:bg-green-900/50 dark:text-green-300' : 'bg-red-500/10 text-red-700 dark:bg-red-900/50 dark:text-red-300'}`}>{item.xp > 0 ? '+' : ''}{item.xp} XP</span>}
                    {'area' in item && item.area && <span className="text-xs font-mono ml-2 p-1 rounded bg-blue-500/10 text-blue-700 dark:bg-blue-900/50 dark:text-blue-300">{item.area}</span>}
                </li>
            ))}
        </ul>
    </div>
);

const AiGoals: React.FC<AiGoalsProps> = ({ userGoals, plan, onNavigate }) => {

    const objectiveIcon = <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5.636 18.364a9 9 0 010-12.728m12.728 0a9 9 0 010 12.728m-9.9-2.829a5 5 0 010-7.07m7.072 0a5 5 0 010 7.07M12 6v6m0 0v6m0-6h6m-6 0H6" /></svg>;
    const motivationIcon = <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z" /></svg>;
    const expectationIcon = <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 11l3-3m0 0l3 3m-3-3v8m0-13a9 9 0 110 18 9 9 0 010-18z" /></svg>;
    const positiveIcon = <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6v6m0 0v6m0-6h6m-6 0H6" /></svg>;
    const negativeIcon = <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M20 12H4" /></svg>;
    const kpiIcon = <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" /></svg>;
    
    return (
        <div className="bg-brand-surface-light dark:bg-brand-surface rounded-xl p-6 shadow-lg space-y-6">
            <div className="text-center">
                <h3 className="text-xl font-bold">Tu Misión Personalizada</h3>
                <p className="text-brand-text-secondary-light dark:text-brand-text-secondary text-sm mt-1">Este es el plan de juego que la IA ha diseñado basado en tus metas.</p>
            </div>
            
            <div className="space-y-4">
                <GoalCard title="Tu Objetivo Principal" content={userGoals.objective} icon={objectiveIcon} />
                <GoalCard title="Tu Motivación (Por qué)" content={userGoals.motivation} icon={motivationIcon} />
                <GoalCard title="Tus Expectativas" content={userGoals.expectation} icon={expectationIcon} />
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                <PlanSection title="Acciones Positivas" items={plan.positiveActions} icon={positiveIcon} actionType="positive" onEdit={() => onNavigate('ACTIONS')} />
                <PlanSection title="Penalizaciones" items={plan.negativeActions} icon={negativeIcon} actionType="negative" onEdit={() => onNavigate('ACTIONS')} />
                <div className="lg:col-span-2">
                    <PlanSection title="KPIs Semanales" items={plan.kpis} icon={kpiIcon} onEdit={() => onNavigate('KPIS')} />
                </div>
            </div>
        </div>
    );
};

export default AiGoals;