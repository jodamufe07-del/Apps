
import React from 'react';
import { Radar, RadarChart, PolarGrid, PolarAngleAxis, ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, LineChart, Line, CartesianGrid } from 'recharts';

interface ProgressAnalysisProps {
  kpiData: { area: string; completion: number }[];
  sentimentData: { date: string; value: number; }[];
}

const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-brand-bg-light dark:bg-brand-bg p-2 border border-gray-300 dark:border-brand-primary/50 rounded-lg shadow-lg">
          <p className="label font-bold text-brand-text-primary-light dark:text-brand-text-primary">{`${label}`}</p>
          <p className="intro text-brand-accent-light dark:text-brand-accent">{`Completado: ${payload[0].value.toFixed(0)}%`}</p>
        </div>
      );
    }
  
    return null;
};

const SentimentTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      const value = payload[0].value;
      let sentimentText = 'Neutral';
      if (value > 0) sentimentText = 'Positivo';
      if (value < 0) sentimentText = 'Negativo';

      return (
        <div className="bg-brand-bg-light dark:bg-brand-bg p-2 border border-gray-300 dark:border-brand-primary/50 rounded-lg shadow-lg">
          <p className="label font-bold text-brand-text-primary-light dark:text-brand-text-primary">{`${label}`}</p>
          <p className="intro text-brand-accent-light dark:text-brand-accent">{`Sentimiento: ${sentimentText}`}</p>
        </div>
      );
    }
    return null;
}

const ProgressAnalysis: React.FC<ProgressAnalysisProps> = ({ kpiData, sentimentData }) => {
  const renderKpiChart = () => {
    if (kpiData.length === 0) {
      return (
        <div className="text-center p-8">
            <h4 className="text-lg font-semibold text-brand-text-primary-light dark:text-brand-text-primary">Análisis de Áreas de Enfoque</h4>
            <p className="text-brand-text-secondary-light dark:text-brand-text-secondary italic mt-2">Añade KPIs para ver un análisis de tu progreso.</p>
        </div>
      );
    }
    
    const chart = kpiData.length < 3 ? (
        <BarChart data={kpiData} margin={{ top: 5, right: 20, left: -10, bottom: 5 }}>
          <XAxis dataKey="area" stroke="currentColor" className="text-brand-text-secondary-light dark:text-brand-text-secondary" fontSize={12} tickLine={false} axisLine={false} />
          <YAxis stroke="currentColor" className="text-brand-text-secondary-light dark:text-brand-text-secondary" fontSize={12} tickLine={false} axisLine={false} unit="%" />
          <Tooltip content={<CustomTooltip />} cursor={{ fill: 'rgba(106, 69, 255, 0.1)' }} />
          <Bar dataKey="completion" className="fill-brand-primary-light dark:fill-brand-primary" radius={[4, 4, 0, 0]} />
        </BarChart>
      ) : (
        <RadarChart cx="50%" cy="50%" outerRadius="80%" data={kpiData}>
          <PolarGrid className="stroke-brand-text-secondary-light dark:stroke-brand-text-secondary" strokeOpacity={0.3} />
          <PolarAngleAxis dataKey="area" className="fill-brand-text-primary-light dark:fill-brand-text-primary" fontSize={14} />
          <Radar name="Progreso" dataKey="completion" className="stroke-brand-primary-light dark:stroke-brand-primary fill-brand-primary-light dark:fill-brand-primary" fillOpacity={0.6} />
          <Tooltip content={<CustomTooltip />} />
        </RadarChart>
      );

    return (
        <div className="h-96">
            <h4 className="text-lg font-semibold text-center mb-2 text-brand-text-primary-light dark:text-brand-text-primary">Rendimiento por Área (Semanal)</h4>
            <ResponsiveContainer width="100%" height="100%">
                {chart}
            </ResponsiveContainer>
        </div>
    );
  }

  const renderSentimentChart = () => {
    if (sentimentData.length === 0) {
        return (
            <div className="text-center p-8">
                <h4 className="text-lg font-semibold text-brand-text-primary-light dark:text-brand-text-primary">Tendencia de Ánimo</h4>
                <p className="text-brand-text-secondary-light dark:text-brand-text-secondary italic mt-2">Completa check-outs diarios para ver tu tendencia.</p>
            </div>
        );
    }

    return (
        <div className="h-96">
            <h4 className="text-lg font-semibold text-center mb-2 text-brand-text-primary-light dark:text-brand-text-primary">Tendencia de Ánimo (Últimos 30 Días)</h4>
            <ResponsiveContainer width="100%" height="100%">
                <LineChart data={sentimentData} margin={{ top: 5, right: 20, left: -10, bottom: 5 }}>
                    <CartesianGrid strokeDasharray="3 3" className="stroke-brand-text-secondary-light/50 dark:stroke-brand-text-secondary/20" />
                    <XAxis dataKey="date" stroke="currentColor" className="text-brand-text-secondary-light dark:text-brand-text-secondary" fontSize={12} />
                    <YAxis domain={[-1.2, 1.2]} tickCount={3} tickFormatter={(v) => { if(v===1) return 'Pos'; if(v===-1) return 'Neg'; if(v===0) return 'Neu'; return ''}} stroke="currentColor" className="text-brand-text-secondary-light dark:text-brand-text-secondary" fontSize={12}/>
                    <Tooltip content={<SentimentTooltip />} />
                    <Line type="monotone" dataKey="value" strokeWidth={2} className="stroke-brand-accent-light dark:stroke-brand-accent" dot={{ r: 4 }} activeDot={{ r: 8 }} />
                </LineChart>
            </ResponsiveContainer>
        </div>
    );
  }

  return (
    <div className="bg-brand-surface-light dark:bg-brand-surface rounded-xl p-6 shadow-lg space-y-8">
        <h3 className="text-xl font-bold text-center text-brand-text-primary-light dark:text-brand-text-primary">Análisis de Progreso</h3>
        {renderKpiChart()}
        <div className="border-t border-gray-200 dark:border-brand-primary/20 my-4"></div>
        {renderSentimentChart()}
    </div>
  );
};

export default ProgressAnalysis;