
import React, { useRef, useEffect, useState } from 'react';
import { Level, AppView } from '../types';
import SparkleEffect from './SparkleEffect';
import { WEEKLY_XP_REWARD_THRESHOLD } from '../constants';
import ProactiveCoachMessage from './ProactiveCoachMessage';

interface DashboardProps {
  level: Level;
  totalXp: number;
  weeklyXp: number;
  rankProgress: number;
  weeklyProgress: number;
  customWeeklyReward: string;
  miniMission?: string;
  proactiveMessage: string | null;
  onXpTargetReady: (pos: { x: number; y: number }) => void;
  showRewardAnimation: boolean;
  onRewardAnimationComplete: () => void;
  onSetCustomReward: (reward: string) => void;
  onDismissProactiveMessage: () => void;
  onNavigate: (view: AppView) => void;
}

const ProgressBar: React.FC<{ progress: number; colorClass: string }> = ({ progress, colorClass }) => (
    <div className="w-full bg-gray-200 dark:bg-brand-bg rounded-full h-2.5">
      <div className={`${colorClass} h-2.5 rounded-full transition-all duration-500 ease-out`} style={{ width: `${progress}%` }}></div>
    </div>
);

const Dashboard: React.FC<DashboardProps> = ({ 
    level, totalXp, weeklyXp, rankProgress, weeklyProgress, customWeeklyReward, 
    miniMission, proactiveMessage, onXpTargetReady, showRewardAnimation, 
    onRewardAnimationComplete, onSetCustomReward, onDismissProactiveMessage, onNavigate 
}) => {
  const xpTargetRef = useRef<HTMLDivElement>(null);
  const [isEditingReward, setIsEditingReward] = useState(false);
  const [rewardText, setRewardText] = useState(customWeeklyReward);

  useEffect(() => {
    setRewardText(customWeeklyReward);
  }, [customWeeklyReward]);

  useEffect(() => {
    const updateTargetPosition = () => {
        if (xpTargetRef.current) {
            const rect = xpTargetRef.current.getBoundingClientRect();
            onXpTargetReady({
                x: rect.left + rect.width / 2,
                y: rect.top + rect.height / 2,
            });
        }
    };
    
    updateTargetPosition();
    
    window.addEventListener('resize', updateTargetPosition);
    return () => window.removeEventListener('resize', updateTargetPosition);
  }, [onXpTargetReady]);

  const remainingWeeklyXp = Math.max(0, WEEKLY_XP_REWARD_THRESHOLD - weeklyXp);

  const handleRewardSave = () => {
      onSetCustomReward(rewardText);
      setIsEditingReward(false);
  };

  return (
    <div className="bg-brand-surface-light dark:bg-brand-surface rounded-xl p-6 shadow-lg" data-tutorial-id="dashboard-step">
      <div className="flex justify-between items-start">
        <div>
          <h2 className="text-xl sm:text-2xl font-bold text-brand-primary-light dark:text-brand-primary">{level.name} — <span className="italic text-brand-text-primary-light dark:text-brand-text-primary">{level.title}</span></h2>
          <p className="text-sm text-brand-text-secondary-light dark:text-brand-text-secondary mt-1">{level.focus}</p>
        </div>
        <div ref={xpTargetRef} className="text-right">
          <p className="text-2xl sm:text-3xl font-bold text-brand-accent-light dark:text-brand-accent">{totalXp.toLocaleString()}</p>
          <p className="text-xs text-brand-text-secondary-light dark:text-brand-text-secondary">Total XP</p>
        </div>
      </div>

      <div className="mt-6 space-y-4">
        <div>
          <div className="flex justify-between items-center mb-1">
            <span className="text-sm font-medium text-brand-text-primary-light dark:text-brand-text-primary">Progreso de Rango</span>
            <span className="text-sm font-medium text-brand-accent-light dark:text-brand-accent">{totalXp % 100} / 100 XP</span>
          </div>
          <ProgressBar progress={rankProgress} colorClass="bg-brand-accent-light dark:bg-brand-accent" />
        </div>
        <div className="relative">
          <div className="flex justify-between items-center mb-1">
            <span className="text-sm font-medium text-brand-text-primary-light dark:text-brand-text-primary">Recompensa Semanal</span>
            <span className="text-sm font-medium text-brand-secondary-light dark:text-brand-secondary">{weeklyXp} / 80 XP</span>
          </div>
          <ProgressBar progress={weeklyProgress} colorClass="bg-brand-secondary-light dark:bg-brand-secondary" />
          {showRewardAnimation && <SparkleEffect onComplete={onRewardAnimationComplete} />}
        </div>
      </div>
      
      <div 
        className="mt-4 p-2 rounded-lg group"
        onClick={() => setIsEditingReward(true)}
      >
        {isEditingReward ? (
          <div className="flex items-center gap-2">
            <input 
              type="text" 
              value={rewardText}
              onChange={(e) => setRewardText(e.target.value)}
              placeholder="Define tu recompensa semanal..."
              className="flex-grow bg-brand-bg-light dark:bg-brand-bg text-sm p-1 rounded border border-brand-primary-light/50 dark:border-brand-primary/50 focus:ring-1 focus:ring-brand-primary-light dark:focus:ring-brand-primary"
              onBlur={handleRewardSave}
              onKeyDown={(e) => e.key === 'Enter' && handleRewardSave()}
              autoFocus
            />
          </div>
        ) : (
          <div className="text-center cursor-pointer">
            <p className="text-xs text-brand-text-secondary-light dark:text-brand-text-secondary">Tu recompensa por alcanzar 80 XP:</p>
            <p className="text-brand-text-primary-light dark:text-brand-text-primary italic font-semibold">{customWeeklyReward || "Toca para definir..."}</p>
          </div>
        )}
      </div>

      {proactiveMessage && (
        <ProactiveCoachMessage 
            message={proactiveMessage}
            onDismiss={onDismissProactiveMessage}
            onNavigate={() => onNavigate('COACH')}
        />
      )}
      
      {miniMission && (
        <div className="mt-6 bg-brand-primary-light/10 dark:bg-brand-primary/20 border border-brand-primary-light/50 dark:border-brand-primary/50 rounded-lg p-4 text-center transition-all duration-500 animate-[toast-in_0.5s_ease-out_forwards]">
            <h4 className="font-bold text-brand-accent-light dark:text-brand-accent flex items-center justify-center gap-2">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M5 2a1 1 0 00-1 1v1h1a1 1 0 010 2H4v1a1 1 0 001 1h2a1 1 0 011 1v4a1 1 0 001 1h2a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 001-1V6h-1a1 1 0 110-2h1V3a1 1 0 00-1-1H5zM4 14a1 1 0 00-1 1v3a1 1 0 001 1h12a1 1 0 001-1v-3a1 1 0 00-1-1H4z" clipRule="evenodd" /></svg>
                Misión del Día
            </h4>
            <p className="text-brand-text-primary-light dark:text-brand-text-primary mt-1 italic">"{miniMission}"</p>
            {remainingWeeklyXp > 0 && (
                <p className="text-xs text-brand-text-secondary-light dark:text-brand-text-secondary mt-2">
                    ¡Estás a solo <span className="font-bold text-brand-secondary-light dark:text-brand-secondary">{remainingWeeklyXp} XP</span> de tu recompensa!
                </p>
            )}
        </div>
      )}
    </div>
  );
};

export default Dashboard;