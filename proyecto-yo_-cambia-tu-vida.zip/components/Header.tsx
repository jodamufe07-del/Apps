
import React from 'react';

const Header: React.FC = () => {
  return (
    <header className="pt-2">
      <h1 className="text-2xl sm:text-3xl md:text-4xl font-bold tracking-tight text-brand-text-primary-light dark:text-brand-text-primary">
        <span className="text-brand-primary-light dark:text-brand-primary">PROYECTO YO</span>
      </h1>
      <p className="text-brand-text-secondary-light dark:text-brand-text-secondary mt-1 text-sm sm:text-base">"Tu vida como juego. Tu disciplina como arma. Tu libertad como meta."</p>
    </header>
  );
};

export default Header;