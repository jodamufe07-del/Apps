
import React, { useState, useCallback } from 'react';
import { getCoachingAdvice } from '../services/geminiService';

interface GroundingChunk {
  web: {
    uri: string;
    title: string;
  };
}

const AiCoach: React.FC = () => {
  const [advice, setAdvice] = useState<string>('Haz una pregunta o pide un consejo sobre un tema específico para empezar.');
  const [sources, setSources] = useState<GroundingChunk[]>([]);
  const [query, setQuery] = useState<string>('');
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  const fetchAdvice = useCallback(async (userQuery: string) => {
    if (!userQuery) return;
    setIsLoading(true);
    setError(null);
    setSources([]);
    try {
      const result = await getCoachingAdvice(userQuery);
      setAdvice(result.text);
      if (result.sources) {
        setSources(result.sources);
      }
    } catch (err) {
      setError('No se pudo contactar al Coach IA. Intenta de nuevo.');
      setAdvice('Hubo un error al generar el consejo.');
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  }, []);
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    fetchAdvice(query);
  };

  return (
    <div className="bg-brand-surface-light dark:bg-brand-surface rounded-xl p-4 shadow-lg flex flex-col items-center">
      <h3 className="text-lg font-semibold mb-2 text-center">IA Coach</h3>
       <div className="w-16 h-16 rounded-full bg-brand-primary-light dark:bg-brand-primary flex items-center justify-center mb-4 shadow-md">
        <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8.228 9c.549-1.165 2.03-2 3.772-2 2.21 0 4 1.343 4 3 0 1.4-1.278 2.575-3.006 2.907-.542.104-.994.54-.994 1.093m0 3h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
        </svg>
      </div>
      <div className="text-left w-full min-h-[80px] bg-brand-bg-light dark:bg-brand-bg p-3 rounded-md">
          {isLoading ? (
            <div className="flex justify-center items-center h-full">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-brand-accent-light dark:border-brand-accent"></div>
            </div>
          ) : (
            <>
            <p className="text-sm text-brand-text-secondary-light dark:text-brand-text-secondary whitespace-pre-wrap">{error || advice}</p>
            {sources.length > 0 && (
              <div className="mt-4 pt-2 border-t border-gray-200 dark:border-brand-primary/20">
                <h4 className="text-xs font-bold text-brand-text-primary-light dark:text-brand-text-primary mb-1">Fuentes:</h4>
                <ul className="list-disc list-inside text-xs space-y-1">
                  {sources.map((source, index) => (
                    <li key={index}>
                      <a href={source.web.uri} target="_blank" rel="noopener noreferrer" className="text-brand-accent-light dark:text-brand-accent hover:underline">
                        {source.web.title || 'Fuente de información'}
                      </a>
                    </li>
                  ))}
                </ul>
              </div>
            )}
            </>
          )}
      </div>
       <form onSubmit={handleSubmit} className="mt-4 w-full flex gap-2">
            <input 
                type="text"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="¿Sobre qué necesitas un consejo?"
                className="flex-grow bg-brand-bg-light dark:bg-brand-bg rounded-lg border-gray-300 dark:border-brand-surface focus:ring-brand-primary-light dark:focus:ring-brand-primary focus:border-brand-primary-light dark:focus:border-brand-primary text-sm p-2"
                disabled={isLoading}
            />
            <button 
                type="submit"
                disabled={isLoading || !query}
                className="bg-brand-primary-light dark:bg-brand-primary hover:bg-brand-primary-light/80 dark:hover:bg-brand-primary/80 text-white font-bold py-2 px-4 rounded-lg transition-colors duration-300 disabled:bg-gray-400 dark:disabled:bg-gray-600 disabled:cursor-not-allowed"
            >
                {isLoading ? '...' : 'Pedir'}
            </button>
       </form>
    </div>
  );
};

export default AiCoach;