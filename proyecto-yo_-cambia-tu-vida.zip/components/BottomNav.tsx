
import React from 'react';
import { AppView } from '../types';

interface BottomNavProps {
  currentView: AppView;
  onNavigate: (view: AppView) => void;
}

const NavItem: React.FC<{
  view: AppView;
  label: string;
  icon: React.ReactNode;
  isActive: boolean;
  onClick: () => void;
  tutorialId?: string;
}> = ({ view, label, icon, isActive, onClick, tutorialId }) => (
  <button
    onClick={onClick}
    className={`flex flex-col items-center justify-center w-full h-full transition-colors duration-200 ${isActive ? 'text-brand-primary-light dark:text-brand-primary' : 'text-brand-text-secondary-light dark:text-brand-text-secondary hover:text-brand-primary-light dark:hover:text-brand-primary'}`}
    data-tutorial-id={tutorialId}
  >
    {icon}
    <span className="text-xs mt-1">{label}</span>
  </button>
);

const CentralNavItem: React.FC<{
  isActive: boolean;
  onClick: () => void;
}> = ({ isActive, onClick }) => (
  <button
    onClick={onClick}
    className={`w-16 h-16 -mt-6 bg-brand-primary-light dark:bg-brand-primary rounded-full shadow-lg flex items-center justify-center transition-transform hover:scale-110 ${isActive ? 'ring-4 ring-white dark:ring-brand-bg' : ''}`}
    aria-label="Dashboard"
  >
    <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2V6zM14 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2V6zM4 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2v-2zM14 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2v-2z" />
    </svg>
  </button>
);

const BottomNav: React.FC<BottomNavProps> = ({ currentView, onNavigate }) => {
  // FIX: Explicitly type navItems to ensure `view` property is of type `AppView`.
  const navItems: { view: AppView; label: string; icon: React.ReactNode, tutorialId?: string }[] = [
    { view: 'ACTIONS', label: 'Acciones', icon: <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14 10h4.764a2 2 0 011.789 2.894l-3.5 7A2 2 0 0115.263 21h-4.017c-.163 0-.326-.02-.485-.06L7 20m7-10V5a2 2 0 00-2-2h-.085a2 2 0 00-1.736.96L7 6m7 4h2V5a2 2 0 00-2-2h-1a2 2 0 00-2 2v1" /></svg>, tutorialId: 'actions-button-step' },
    { view: 'KPIS', label: 'KPIs', icon: <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" /></svg> },
    { view: 'FOCUS_MODE', label: 'Foco', icon: <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" /></svg> },
    { view: 'SETTINGS', label: 'Ajustes', icon: <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" /></svg> }
  ];

  return (
    <div className="fixed bottom-0 left-0 right-0 h-16 bg-brand-surface-light dark:bg-brand-surface border-t border-gray-200 dark:border-brand-primary/20 shadow-[0_-5px_15px_-5px_rgba(0,0,0,0.1)]" data-tutorial-id="bottom-nav-step">
      <div className="flex justify-around items-center h-full max-w-4xl mx-auto px-2">
        <NavItem {...navItems[0]} isActive={currentView === navItems[0].view} onClick={() => onNavigate(navItems[0].view)} />
        <NavItem {...navItems[1]} isActive={currentView === navItems[1].view} onClick={() => onNavigate(navItems[1].view)} />
        <div className="w-20 flex justify-center">
            <CentralNavItem isActive={currentView === 'DASHBOARD'} onClick={() => onNavigate('DASHBOARD')} />
        </div>
        <NavItem {...navItems[2]} isActive={currentView === navItems[2].view} onClick={() => onNavigate(navItems[2].view)} />
        <NavItem {...navItems[3]} isActive={currentView === navItems[3].view} onClick={() => onNavigate(navItems[3].view)} />
      </div>
    </div>
  );
};

export default BottomNav;