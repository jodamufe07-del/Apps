
import React from 'react';
import { LogEntry } from '../types';

interface LogbookProps {
  entries: LogEntry[];
}

const LogItem: React.FC<{ entry: LogEntry }> = ({ entry }) => {
    const date = new Date(entry.date);
    const formattedDate = date.toLocaleDateString('es-ES', {
        year: 'numeric',
        month: 'long',
        day: 'numeric',
    });
    const formattedTime = date.toLocaleTimeString('es-ES', {
        hour: '2-digit',
        minute: '2-digit',
    });
    
    return (
        <details className="bg-brand-bg-light dark:bg-brand-bg rounded-lg overflow-hidden">
            <summary className="p-4 cursor-pointer flex justify-between items-center list-none">
                <div className="flex-1">
                    <p className="font-semibold text-brand-text-primary-light dark:text-brand-text-primary">{formattedDate}</p>
                    <p className="text-xs text-brand-text-secondary-light dark:text-brand-text-secondary">{formattedTime}</p>
                    <p className="text-sm text-brand-text-secondary-light dark:text-brand-text-secondary mt-2 italic">"{entry.reflection}"</p>
                </div>
                <div className="text-right ml-4">
                    <p className={`text-xl font-bold ${entry.dailyXp >= 0 ? 'text-green-500' : 'text-red-500'}`}>
                        {entry.dailyXp > 0 ? '+' : ''}{entry.dailyXp} XP
                    </p>
                </div>
            </summary>
            <div className="p-4 border-t border-gray-200 dark:border-brand-primary/20 bg-gray-50 dark:bg-black/20">
                <h4 className="font-semibold text-brand-accent-light dark:text-brand-accent mb-2">Detalles del Check-in:</h4>
                <ul className="text-sm text-brand-text-secondary-light dark:text-brand-text-secondary list-disc list-inside space-y-1">
                    <li><span className="font-medium text-brand-text-primary-light dark:text-brand-text-primary">Meta del Día:</span> {entry.checkin.dailyGoal}</li>
                    <li><span className="font-medium text-brand-text-primary-light dark:text-brand-text-primary">Prioridades:</span> {entry.checkin.priorities}</li>
                    <li><span className="font-medium text-brand-text-primary-light dark:text-brand-text-primary">Estado:</span> {entry.checkin.status}</li>
                    <li><span className="font-medium text-brand-text-primary-light dark:text-brand-text-primary">Mini Misión:</span> {entry.checkin.miniMission}</li>
                </ul>
            </div>
        </details>
    )
}

const Logbook: React.FC<LogbookProps> = ({ entries }) => {
  return (
    <div className="bg-brand-surface-light dark:bg-brand-surface rounded-xl p-6 shadow-lg">
      <h3 className="text-xl font-bold mb-4 text-center">Historial Diario</h3>
      {entries.length === 0 ? (
        <p className="text-center text-brand-text-secondary-light dark:text-brand-text-secondary italic">Completa tu primer día para ver tu historial.</p>
      ) : (
        <div className="space-y-3 max-h-96 overflow-y-auto pr-2">
            {entries.map(entry => (
                <LogItem key={entry.id} entry={entry} />
            ))}
        </div>
      )}
    </div>
  );
};

export default Logbook;