
import React, { useState, useEffect } from 'react';
import { Kpi } from '../types';

interface KpiTrackerProps {
  kpis: Kpi[];
  onToggle: (indicator: string) => void;
  onUpdateKpis: (kpis: Kpi[]) => void;
}

const KpiEditor: React.FC<{
    kpi: Omit<Kpi, 'completed'>;
    onSave: (updatedKpi: Omit<Kpi, 'completed'>) => void;
    onCancel: () => void;
}> = ({ kpi, onSave, onCancel }) => {
    const [indicator, setIndicator] = useState(kpi.indicator);
    const [area, setArea] = useState(kpi.area);

    const handleSave = () => {
        if (indicator && area) {
            onSave({ indicator, area });
        }
    };

    return (
        <div className="flex items-center gap-2 p-2 bg-brand-bg-light dark:bg-brand-bg rounded-lg">
            <input type="text" value={indicator} onChange={e => setIndicator(e.target.value)} className="flex-grow bg-brand-surface-light dark:bg-brand-surface p-1 rounded text-sm" placeholder="Indicador"/>
            <input type="text" value={area} onChange={e => setArea(e.target.value)} className="w-24 bg-brand-surface-light dark:bg-brand-surface p-1 rounded text-sm" placeholder="Área"/>
            <button onClick={handleSave} className="p-1 text-green-500 hover:text-green-400">&#10003;</button>
            <button onClick={onCancel} className="p-1 text-red-500 hover:text-red-400">&#10005;</button>
        </div>
    );
};

const KpiItem: React.FC<{
    kpi: Kpi;
    isEditing: boolean;
    onToggle: (indicator: string) => void;
    onDelete: () => void;
    onEdit: () => void;
}> = ({ kpi, isEditing, onToggle, onDelete, onEdit }) => {
    if (isEditing) {
        return (
            <div className="flex items-center p-3 bg-brand-bg-light dark:bg-brand-bg rounded-lg">
                <div className="flex-grow">
                    <span className="font-medium text-brand-text-primary-light dark:text-brand-text-primary">{kpi.indicator}</span>
                    <p className="text-xs text-brand-text-secondary-light dark:text-brand-text-secondary">{kpi.area}</p>
                </div>
                <div className="flex items-center gap-2">
                    <button onClick={onEdit} className="p-1 hover:text-brand-text-primary-light dark:hover:text-white">✏️</button>
                    <button onClick={onDelete} className="p-1 hover:text-brand-text-primary-light dark:hover:text-white">🗑️</button>
                </div>
            </div>
        );
    }

    return (
        <label htmlFor={kpi.indicator} className="flex items-center p-3 bg-brand-bg-light dark:bg-brand-bg rounded-lg cursor-pointer hover:bg-brand-primary-light/10 dark:hover:bg-brand-primary/10 transition-colors duration-200">
            <input
                id={kpi.indicator}
                type="checkbox"
                checked={kpi.completed}
                onChange={() => onToggle(kpi.indicator)}
                className="h-5 w-5 rounded bg-brand-bg-light dark:bg-brand-bg border-brand-text-secondary-light dark:border-brand-text-secondary text-brand-primary-light dark:text-brand-primary focus:ring-brand-primary-light dark:focus:ring-brand-primary kpi-check"
            />
            <div className="ml-3 text-sm">
                <span className={`font-medium transition-all duration-300 ${kpi.completed ? 'text-brand-text-secondary-light dark:text-brand-text-secondary line-through' : 'text-brand-text-primary-light dark:text-brand-text-primary'}`}>{kpi.indicator}</span>
                <p className="text-xs text-brand-text-secondary-light dark:text-brand-text-secondary">{kpi.area}</p>
            </div>
        </label>
    );
};

const KpiTracker: React.FC<KpiTrackerProps> = ({ kpis, onToggle, onUpdateKpis }) => {
  const [isEditing, setIsEditing] = useState(false);
  const [localKpis, setLocalKpis] = useState(kpis);
  const [editingKpiIndex, setEditingKpiIndex] = useState<number | null>(null);
  const [isAdding, setIsAdding] = useState(false);

  useEffect(() => {
    setLocalKpis(kpis);
  }, [kpis]);
  
  const handleSaveChanges = () => {
    onUpdateKpis(localKpis);
    setIsEditing(false);
  };
  
  const handleCancelChanges = () => {
    setLocalKpis(kpis);
    setIsEditing(false);
  };

  const handleDelete = (index: number) => {
    setLocalKpis(prev => prev.filter((_, i) => i !== index));
  };
  
  const handleSaveEdit = (updatedKpi: Omit<Kpi, 'completed'>) => {
    if (editingKpiIndex === null) return;
    setLocalKpis(prev => prev.map((k, i) => i === editingKpiIndex ? {...k, ...updatedKpi} : k));
    setEditingKpiIndex(null);
  };
  
  const handleSaveNew = (newKpi: Omit<Kpi, 'completed'>) => {
    setLocalKpis(prev => [...prev, {...newKpi, completed: false}]);
    setIsAdding(false);
  };

  return (
    <div className="bg-brand-surface-light dark:bg-brand-surface rounded-xl p-4 shadow-lg">
      <h3 className="text-lg font-semibold mb-4 text-center">KPIs de Crecimiento Semanal</h3>
       <div className="flex justify-center items-center gap-4 mb-4">
          {isEditing ? (
              <>
                  <button onClick={handleSaveChanges} className="bg-green-600 hover:bg-green-500 text-white font-bold py-2 px-4 rounded-lg transition-colors text-sm">Guardar</button>
                  <button onClick={handleCancelChanges} className="bg-gray-600 hover:bg-gray-500 text-white font-bold py-2 px-4 rounded-lg transition-colors text-sm">Cancelar</button>
              </>
          ) : (
              <button onClick={() => setIsEditing(true)} className="bg-brand-primary-light dark:bg-brand-primary hover:bg-brand-primary-light/80 dark:hover:bg-brand-primary/80 text-white font-bold py-2 px-4 rounded-lg transition-colors text-sm">Editar KPIs</button>
          )}
        </div>

      <div className="space-y-2">
        {localKpis.map((kpi, index) =>
            editingKpiIndex === index ? (
                <KpiEditor key={index} kpi={kpi} onSave={handleSaveEdit} onCancel={() => setEditingKpiIndex(null)} />
            ) : (
                <KpiItem key={kpi.indicator} kpi={kpi} isEditing={isEditing} onToggle={onToggle} onDelete={() => handleDelete(index)} onEdit={() => setEditingKpiIndex(index)} />
            )
        )}
        {isAdding && (
            <KpiEditor kpi={{indicator: '', area: ''}} onSave={handleSaveNew} onCancel={() => setIsAdding(false)} />
        )}
        {isEditing && !isAdding && (
             <button onClick={() => setIsAdding(true)} className="w-full p-2 text-sm rounded-lg bg-brand-bg-light dark:bg-brand-bg hover:bg-brand-primary-light/10 dark:hover:bg-brand-primary/20 transition-colors mt-2">
              + Añadir KPI
            </button>
        )}
      </div>
    </div>
  );
};

export default KpiTracker;