import React, { useState, useLayoutEffect, useRef } from 'react';

interface TutorialGuideProps {
    onComplete: () => void;
}

interface Step {
    elementId: string;
    title: string;
    content: string;
    position?: 'top' | 'bottom' | 'left' | 'right';
}

const steps: Step[] = [
    {
        elementId: 'dashboard-step',
        title: 'Bienvenido a tu Dashboard',
        content: 'Aquí verás un resumen de tu progreso: tu nivel, XP total, y tu avance semanal. Es tu centro de mando.',
        position: 'bottom',
    },
    {
        elementId: 'checkin-step',
        title: 'Tu Ritual Diario: Check-in',
        content: 'Cada día comienza aquí. Define tus prioridades y tu meta para empezar con claridad y propósito.',
        position: 'top',
    },
    {
        elementId: 'bottom-nav-step',
        title: 'Navegación Principal',
        content: 'Usa esta barra para moverte entre las secciones más importantes de la aplicación de forma rápida.',
        position: 'top',
    },
    {
        elementId: 'actions-button-step',
        title: 'Registra tus Acciones',
        content: 'Toca aquí para ir a la sección de Acciones, donde puedes sumar o restar XP según tus hábitos diarios.',
        position: 'top',
    },
    {
        elementId: 'top-menu-step',
        title: 'Menú Avanzado',
        content: 'Aquí encontrarás herramientas poderosas como tus Logros, el Árbol de Habilidades, informes y mucho más.',
        position: 'bottom',
    }
];

const TutorialGuide: React.FC<TutorialGuideProps> = ({ onComplete }) => {
    const [currentStep, setCurrentStep] = useState(0);
    const [highlightStyle, setHighlightStyle] = useState<React.CSSProperties>({});
    const [tooltipStyle, setTooltipStyle] = useState<React.CSSProperties>({});
    const tooltipRef = useRef<HTMLDivElement>(null);

    const step = steps[currentStep];

    useLayoutEffect(() => {
        const updatePosition = () => {
            const element = document.querySelector(`[data-tutorial-id="${step.elementId}"]`);
            const tooltip = tooltipRef.current;
            if (!element || !tooltip) return;

            const elementRect = element.getBoundingClientRect();
            const tooltipRect = tooltip.getBoundingClientRect();
            
            // Highlight style
            setHighlightStyle({
                top: `${elementRect.top - 4}px`,
                left: `${elementRect.left - 4}px`,
                width: `${elementRect.width + 8}px`,
                height: `${elementRect.height + 8}px`,
            });
            
            const PADDING = 16; // Space from element and screen edges
            let top = 0;
            let left = 0;
            let transform = '';

            let position = step.position || 'bottom';

            // Vertical positioning check
            const spaceBottom = window.innerHeight - elementRect.bottom - tooltipRect.height - PADDING;
            const spaceTop = elementRect.top - tooltipRect.height - PADDING;

            if (position === 'bottom' && spaceBottom < 0 && spaceTop >= 0) {
                position = 'top';
            }
            if (position === 'top' && spaceTop < 0 && spaceBottom >= 0) {
                position = 'bottom';
            }

            switch (position) {
                case 'top':
                    top = elementRect.top - PADDING;
                    left = elementRect.left + elementRect.width / 2;
                    transform = 'translate(-50%, -100%)';
                    break;
                case 'left':
                    top = elementRect.top + elementRect.height / 2;
                    left = elementRect.left - PADDING;
                    transform = 'translate(-100%, -50%)';
                    break;
                case 'right':
                    top = elementRect.top + elementRect.height / 2;
                    left = elementRect.right + PADDING;
                    transform = 'translate(0, -50%)';
                    break;
                case 'bottom':
                default:
                    top = elementRect.bottom + PADDING;
                    left = elementRect.left + elementRect.width / 2;
                    transform = 'translate(-50%, 0)';
                    break;
            }

            // Horizontal boundary check
            const tempLeft = left - (tooltipRect.width / 2); // Assuming center alignment
            if (tempLeft < PADDING) {
                left = PADDING + (tooltipRect.width / 2);
            }
            if (tempLeft + tooltipRect.width > window.innerWidth - PADDING) {
                left = window.innerWidth - PADDING - (tooltipRect.width / 2);
            }
            
            setTooltipStyle({
                top: `${top}px`,
                left: `${left}px`,
                transform,
                opacity: 1, // Show it after position is calculated
            });
        };
        
        // Hide tooltip briefly while calculating to prevent flicker
        setTooltipStyle({ opacity: 0 });
        
        // We use a small timeout to ensure the DOM has painted the tooltip
        // so we can measure it correctly.
        const timer = setTimeout(updatePosition, 50);

        window.addEventListener('resize', updatePosition);
        return () => {
            window.removeEventListener('resize', updatePosition);
            clearTimeout(timer);
        };
    }, [currentStep, step]);

    const handleNext = () => {
        if (currentStep < steps.length - 1) {
            setCurrentStep(currentStep + 1);
        } else {
            onComplete();
        }
    };

    const handlePrev = () => {
        if (currentStep > 0) {
            setCurrentStep(currentStep - 1);
        }
    };

    return (
        <div className="fixed inset-0 z-[9990]">
            <div className="tutorial-highlight" style={highlightStyle}></div>
            <div ref={tooltipRef} className="tutorial-tooltip" style={tooltipStyle}>
                <h4 className="font-bold text-brand-primary-light dark:text-brand-primary mb-2">{step.title}</h4>
                <p className="text-sm text-brand-text-secondary-light dark:text-brand-text-secondary">{step.content}</p>
                <div className="flex justify-between items-center mt-4">
                    <span className="text-xs text-brand-text-secondary-light dark:text-brand-text-secondary">{currentStep + 1} / {steps.length}</span>
                    <div className="flex gap-2">
                        {currentStep > 0 && <button onClick={handlePrev} className="text-xs font-semibold px-3 py-1 rounded-md hover:bg-gray-200 dark:hover:bg-brand-surface">Anterior</button>}
                        <button onClick={handleNext} className="text-xs font-semibold px-3 py-1 rounded-md bg-brand-primary-light dark:bg-brand-primary text-white">
                            {currentStep === steps.length - 1 ? 'Finalizar' : 'Siguiente'}
                        </button>
                    </div>
                </div>
                <button onClick={onComplete} className="absolute top-2 right-2 text-brand-text-secondary-light dark:text-brand-text-secondary hover:text-brand-text-primary-light dark:hover:text-white">&times;</button>
            </div>
        </div>
    );
};

export default TutorialGuide;
