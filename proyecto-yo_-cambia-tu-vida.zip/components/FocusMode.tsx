
import React, { useState, useEffect, useCallback, useMemo } from 'react';

interface FocusModeProps {
    onFocusSessionComplete: () => void;
}

type TimerMode = 'focus' | 'shortBreak' | 'longBreak';

const formatTime = (seconds: number): string => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
};

const FocusMode: React.FC<FocusModeProps> = ({ onFocusSessionComplete }) => {
    const [settings, setSettings] = useState({
        focus: 25, // minutes
        shortBreak: 5,
        longBreak: 15,
    });
    const [mode, setMode] = useState<TimerMode>('focus');
    const [isActive, setIsActive] = useState(false);
    const [secondsLeft, setSecondsLeft] = useState(settings.focus * 60);
    const [focusSessions, setFocusSessions] = useState(0);

    const timeForCurrentMode = useMemo(() => {
        return (settings[mode] || 25) * 60;
    }, [mode, settings]);

    useEffect(() => {
        setSecondsLeft(timeForCurrentMode);
    }, [timeForCurrentMode]);

    useEffect(() => {
        let interval: NodeJS.Timeout | null = null;
        if (isActive && secondsLeft > 0) {
            interval = setInterval(() => {
                setSecondsLeft(prev => prev - 1);
            }, 1000);
        } else if (isActive && secondsLeft === 0) {
            // Timer finished
            setIsActive(false);
            if (mode === 'focus') {
                onFocusSessionComplete();
                setFocusSessions(prev => prev + 1);
                if ((focusSessions + 1) % 4 === 0) {
                    setMode('longBreak');
                } else {
                    setMode('shortBreak');
                }
            } else {
                setMode('focus');
            }
        }
        return () => {
            if (interval) clearInterval(interval);
        };
    }, [isActive, secondsLeft, mode, focusSessions, onFocusSessionComplete]);

    const toggleTimer = () => setIsActive(!isActive);

    const resetTimer = useCallback(() => {
        setIsActive(false);
        setSecondsLeft(timeForCurrentMode);
    }, [timeForCurrentMode]);

    const selectMode = (newMode: TimerMode) => {
        if(isActive) {
            if (!window.confirm('¿Cambiar de modo? Se reiniciará el temporizador actual.')) {
                return;
            }
        }
        setMode(newMode);
        setIsActive(false);
        setSecondsLeft((settings[newMode] || 25) * 60);
    };

    const progress = (secondsLeft / timeForCurrentMode) * 100;
    const circumference = 2 * Math.PI * 140; // 140 is the radius
    const strokeDashoffset = circumference - (progress / 100) * circumference;
    
    const modeTexts: Record<TimerMode, string> = {
        focus: 'Sesión de Foco',
        shortBreak: 'Descanso Corto',
        longBreak: 'Descanso Largo',
    };

    return (
        <div className="bg-brand-surface-light dark:bg-brand-surface rounded-xl p-6 shadow-lg flex flex-col items-center">
            <h3 className="text-xl font-bold mb-4">Modo Foco</h3>
            <div className="flex space-x-2 mb-6">
                {(['focus', 'shortBreak', 'longBreak'] as TimerMode[]).map(m => (
                    <button
                        key={m}
                        onClick={() => selectMode(m)}
                        className={`px-4 py-1 rounded-full text-sm font-semibold transition-colors ${mode === m ? 'bg-brand-primary-light dark:bg-brand-primary text-white' : 'bg-brand-bg-light dark:bg-brand-bg hover:bg-brand-primary-light/10 dark:hover:bg-brand-primary/20'}`}
                    >
                        {modeTexts[m]}
                    </button>
                ))}
            </div>

            <div className="relative w-80 h-80 flex items-center justify-center mb-6">
                <svg className="absolute w-full h-full" viewBox="0 0 300 300">
                    <circle cx="150" cy="150" r="140" strokeWidth="10" className="stroke-brand-bg-light dark:stroke-brand-bg" fill="none" />
                    <circle
                        cx="150" cy="150" r="140" strokeWidth="10"
                        className="stroke-brand-accent-light dark:stroke-brand-accent" fill="none"
                        transform="rotate(-90 150 150)"
                        strokeDasharray={circumference}
                        strokeDashoffset={strokeDashoffset}
                        style={{ transition: 'stroke-dashoffset 0.5s linear' }}
                        strokeLinecap="round"
                    />
                </svg>
                <div className="z-10 text-center">
                    <p className="text-6xl font-mono font-bold">{formatTime(secondsLeft)}</p>
                    <p className="text-brand-text-secondary-light dark:text-brand-text-secondary">Sesiones completadas: {focusSessions}</p>
                </div>
            </div>

            <div className="flex space-x-4">
                <button
                    onClick={toggleTimer}
                    className="w-32 bg-brand-primary-light dark:bg-brand-primary hover:bg-brand-primary-light/80 dark:hover:bg-brand-primary/80 text-white font-bold py-3 px-4 rounded-lg transition-colors text-lg"
                >
                    {isActive ? 'Pausar' : 'Iniciar'}
                </button>
                <button onClick={resetTimer} className="w-32 bg-brand-bg-light dark:bg-brand-bg hover:bg-gray-200 dark:hover:bg-brand-surface text-brand-text-primary-light dark:text-brand-text-primary font-bold py-3 px-4 rounded-lg transition-colors">
                    Reiniciar
                </button>
            </div>
        </div>
    );
};

export default FocusMode;