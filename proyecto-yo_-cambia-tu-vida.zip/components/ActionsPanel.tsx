
import React, { useState, useEffect } from 'react';
import { Action } from '../types';

interface ActionsPanelProps {
  positiveActions: Action[];
  negativeActions: Action[];
  onXpChange: (xp: number, action?: Action) => void;
  onTriggerAnimation: (xp: number, event: React.MouseEvent) => void;
  onUpdateActions: (positive: Action[], negative: Action[]) => void;
}

const ActionEditor: React.FC<{
    action: Action;
    onSave: (updatedAction: Action) => void;
    onCancel: () => void;
}> = ({ action, onSave, onCancel }) => {
    const [description, setDescription] = useState(action.description);
    const [xp, setXp] = useState(action.xp.toString());

    const handleSave = () => {
        const xpValue = parseInt(xp, 10);
        if (description && !isNaN(xpValue)) {
            onSave({ description, xp: xpValue });
        }
    };

    return (
        <div className="flex items-center gap-2 p-2 bg-brand-bg-light dark:bg-brand-bg rounded-lg">
            <input type="text" value={description} onChange={e => setDescription(e.target.value)} className="flex-grow bg-brand-surface-light dark:bg-brand-surface p-1 rounded text-sm" placeholder="Descripción"/>
            <input type="number" value={xp} onChange={e => setXp(e.target.value)} className="w-16 bg-brand-surface-light dark:bg-brand-surface p-1 rounded text-sm" placeholder="XP"/>
            <button onClick={handleSave} className="p-1 text-green-500 hover:text-green-400">&#10003;</button>
            <button onClick={onCancel} className="p-1 text-red-500 hover:text-red-400">&#10005;</button>
        </div>
    );
};


const ActionItem: React.FC<{
    action: Action,
    isPositive: boolean,
    isEditing: boolean,
    onDelete: () => void,
    onEdit: () => void,
    onTrigger: (event: React.MouseEvent) => void
}> = ({ action, isPositive, isEditing, onDelete, onEdit, onTrigger }) => {
    const baseClasses = "w-full text-left p-3 rounded-lg flex justify-between items-center transition-transform duration-200";
    const positiveClasses = "bg-green-500/10 text-green-700 dark:bg-green-600/20 dark:text-green-300";
    const negativeClasses = "bg-red-500/10 text-red-700 dark:bg-red-600/20 dark:text-red-300";
    const hoverClasses = isPositive ? "hover:bg-green-500/20" : "hover:bg-red-500/20";

    if (isEditing) {
        return (
             <div className={`${baseClasses} ${isPositive ? positiveClasses : negativeClasses}`}>
                <span>{action.description}</span>
                <div className="flex items-center gap-2">
                    <span className="font-bold">{isPositive ? '+' : ''}{action.xp} XP</span>
                    <button onClick={onEdit} className="p-1 hover:text-brand-text-primary-light dark:hover:text-white">✏️</button>
                    <button onClick={onDelete} className="p-1 hover:text-brand-text-primary-light dark:hover:text-white">🗑️</button>
                </div>
            </div>
        );
    }

    return (
        <button onClick={onTrigger} className={`${baseClasses} hover:scale-105 ${hoverClasses} ${isPositive ? positiveClasses : negativeClasses}`}>
            <span>{action.description}</span>
            <span className="font-bold">{isPositive ? '+' : ''}{action.xp} XP</span>
        </button>
    );
};


const ActionsPanel: React.FC<ActionsPanelProps> = ({ positiveActions, negativeActions, onXpChange, onTriggerAnimation, onUpdateActions }) => {
  const [isEditing, setIsEditing] = useState(false);
  const [localPositive, setLocalPositive] = useState(positiveActions);
  const [localNegative, setLocalNegative] = useState(negativeActions);
  const [editingAction, setEditingAction] = useState<{action: Action, isPositive: boolean, index: number} | null>(null);
  const [isAdding, setIsAdding] = useState<{isPositive: boolean} | null>(null);
  
  useEffect(() => {
    setLocalPositive(positiveActions);
    setLocalNegative(negativeActions);
  }, [positiveActions, negativeActions]);

  const handleTrigger = (event: React.MouseEvent, action: Action) => {
    onXpChange(action.xp, action.xp < 0 ? action : undefined);
    onTriggerAnimation(action.xp, event);
  };

  const handleSaveChanges = () => {
    onUpdateActions(localPositive, localNegative);
    setIsEditing(false);
  };
  
  const handleCancelChanges = () => {
    setLocalPositive(positiveActions);
    setLocalNegative(negativeActions);
    setIsEditing(false);
  };
  
  const handleDelete = (index: number, isPositive: boolean) => {
    if (isPositive) {
        setLocalPositive(prev => prev.filter((_, i) => i !== index));
    } else {
        setLocalNegative(prev => prev.filter((_, i) => i !== index));
    }
  };

  const handleEdit = (action: Action, index: number, isPositive: boolean) => {
    setEditingAction({action, index, isPositive});
  };
  
  const handleSaveEdit = (updatedAction: Action) => {
    if(!editingAction) return;
    const {index, isPositive} = editingAction;
    if (isPositive) {
        setLocalPositive(prev => prev.map((a, i) => i === index ? updatedAction : a));
    } else {
        setLocalNegative(prev => prev.map((a, i) => i === index ? updatedAction : a));
    }
    setEditingAction(null);
  };

  const handleSaveNew = (newAction: Action) => {
    if (!isAdding) return;
    if (isAdding.isPositive) {
        setLocalPositive(prev => [...prev, newAction]);
    } else {
        setLocalNegative(prev => [...prev, newAction]);
    }
    setIsAdding(null);
  }

  const renderActionList = (actions: Action[], isPositive: boolean) => (
    <div className="space-y-2">
      {actions.map((action, index) => 
        editingAction && editingAction.index === index && editingAction.isPositive === isPositive ? (
            <ActionEditor key={index} action={action} onSave={handleSaveEdit} onCancel={() => setEditingAction(null)}/>
        ) : (
            <ActionItem 
                key={index} 
                action={action} 
                isPositive={isPositive} 
                isEditing={isEditing}
                onDelete={() => handleDelete(index, isPositive)}
                onEdit={() => handleEdit(action, index, isPositive)}
                onTrigger={(e) => handleTrigger(e, action)} 
            />
        )
      )}
      {isAdding && isAdding.isPositive === isPositive && (
          <ActionEditor 
              action={{description: '', xp: isPositive ? 5 : -5}}
              onSave={handleSaveNew}
              onCancel={() => setIsAdding(null)}
          />
      )}
      {isEditing && !isAdding && (
          <button onClick={() => setIsAdding({isPositive})} className="w-full p-2 text-sm rounded-lg bg-brand-bg-light dark:bg-brand-bg hover:bg-brand-primary-light/10 dark:hover:bg-brand-primary/20 transition-colors">
              + Añadir {isPositive ? 'Acción' : 'Penalización'}
          </button>
      )}
    </div>
  );

  return (
    <div className="space-y-6">
        <div className="flex justify-center items-center gap-4">
          {isEditing ? (
              <>
                  <button onClick={handleSaveChanges} className="bg-green-600 hover:bg-green-500 text-white font-bold py-2 px-6 rounded-lg transition-colors">Guardar</button>
                  <button onClick={handleCancelChanges} className="bg-gray-600 hover:bg-gray-500 text-white font-bold py-2 px-6 rounded-lg transition-colors">Cancelar</button>
              </>
          ) : (
              <button onClick={() => setIsEditing(true)} className="bg-brand-primary-light dark:bg-brand-primary hover:bg-brand-primary-light/80 dark:hover:bg-brand-primary/80 text-white font-bold py-2 px-6 rounded-lg transition-colors">Editar Acciones</button>
          )}
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="bg-brand-surface-light dark:bg-brand-surface rounded-xl p-4 shadow-lg">
            <h3 className="text-lg font-semibold mb-4 text-center text-green-600 dark:text-green-400">Acciones Positivas</h3>
            {renderActionList(localPositive, true)}
          </div>
          <div className="bg-brand-surface-light dark:bg-brand-surface rounded-xl p-4 shadow-lg">
            <h3 className="text-lg font-semibold mb-4 text-center text-red-600 dark:text-red-400">Penalizaciones</h3>
            {renderActionList(localNegative, false)}
          </div>
        </div>
    </div>
  );
};

export default ActionsPanel;