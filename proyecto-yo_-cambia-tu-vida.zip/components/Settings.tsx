
import React, { useState } from 'react';

interface SettingsProps {
    currentTheme: 'light' | 'dark';
    onThemeChange: (theme: 'light' | 'dark') => void;
    currentName: string;
    onNameChange: (newName: string) => void;
}

const Settings: React.FC<SettingsProps> = ({ currentTheme, onThemeChange, currentName, onNameChange }) => {
    const [name, setName] = useState(currentName);

    const handleNameSave = (e: React.FormEvent) => {
        e.preventDefault();
        onNameChange(name);
    };

    return (
        <div className="bg-brand-surface-light dark:bg-brand-surface rounded-xl p-6 shadow-lg space-y-8">
            <h3 className="text-xl font-bold text-center text-brand-text-primary-light dark:text-brand-text-primary">Configuración</h3>

            {/* Theme Settings */}
            <div className="space-y-4">
                <h4 className="text-lg font-semibold text-brand-text-primary-light dark:text-brand-text-primary">Estilo Visual</h4>
                <div className="flex items-center justify-center p-2 rounded-lg bg-brand-bg-light dark:bg-brand-bg space-x-2">
                    <button 
                        onClick={() => onThemeChange('light')}
                        className={`w-full py-2 px-4 rounded-md text-sm font-semibold transition-colors ${currentTheme === 'light' ? 'bg-brand-primary-light text-white shadow' : 'hover:bg-gray-200'}`}
                    >
                        Claro
                    </button>
                    <button 
                        onClick={() => onThemeChange('dark')}
                        className={`w-full py-2 px-4 rounded-md text-sm font-semibold transition-colors ${currentTheme === 'dark' ? 'bg-brand-primary text-white shadow' : 'hover:bg-brand-surface'}`}
                    >
                        Oscuro
                    </button>
                </div>
            </div>

            {/* User Name Settings */}
            <div className="space-y-4">
                <h4 className="text-lg font-semibold text-brand-text-primary-light dark:text-brand-text-primary">Perfil del Héroe</h4>
                <form onSubmit={handleNameSave} className="space-y-2">
                     <div>
                        <label htmlFor="heroName" className="block text-sm font-medium text-brand-text-secondary-light dark:text-brand-text-secondary mb-1">Nombre de Héroe</label>
                        <input
                            id="heroName"
                            type="text"
                            value={name}
                            onChange={(e) => setName(e.target.value)}
                            className="w-full bg-brand-bg-light dark:bg-brand-bg rounded-md border-gray-300 dark:border-brand-surface focus:ring-brand-primary-light dark:focus:ring-brand-primary focus:border-brand-primary-light dark:focus:border-brand-primary text-md p-2"
                        />
                    </div>
                    <button
                        type="submit"
                        className="w-full bg-brand-primary-light dark:bg-brand-primary hover:bg-brand-primary-light/80 dark:hover:bg-brand-primary/80 text-white font-bold py-2 px-4 rounded-lg transition-colors duration-300"
                    >
                        Guardar Nombre
                    </button>
                </form>
            </div>
        </div>
    );
};

export default Settings;