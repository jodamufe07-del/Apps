

import React, { useEffect, useMemo } from 'react';

const SPARKLE_COUNT = 15;
const ANIMATION_DURATION = 700; // in ms, matches CSS

const SparkleEffect: React.FC<{ onComplete: () => void }> = ({ onComplete }) => {
  useEffect(() => {
    const timer = setTimeout(onComplete, ANIMATION_DURATION);
    return () => clearTimeout(timer);
  }, [onComplete]);

  const sparkles = useMemo(() => {
    return Array.from({ length: SPARKLE_COUNT }).map((_, i) => {
      const size = Math.random() * 8 + 4; // size between 4px and 12px
      return {
        id: i,
        style: {
          top: `${Math.random() * 100}%`,
          left: `${Math.random() * 100}%`,
          width: `${size}px`,
          height: `${size}px`,
          animationDelay: `${Math.random() * 0.5}s`,
        },
      };
    });
  }, []);

  return (
    <div className="absolute inset-0 pointer-events-none overflow-hidden">
      {sparkles.map(sparkle => (
        <div key={sparkle.id} className="sparkle" style={sparkle.style} />
      ))}
    </div>
  );
};

export default SparkleEffect;