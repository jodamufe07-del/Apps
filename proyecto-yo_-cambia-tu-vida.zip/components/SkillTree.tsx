
import React from 'react';
import { UserState } from '../types';
import { SKILL_TREE } from '../constants';

interface SkillTreeProps {
    userState: UserState;
    onUnlockSkill: (skillId: string) => void;
}

const SkillTree: React.FC<SkillTreeProps> = ({ userState, onUnlockSkill }) => {
    const { skillPoints, unlockedSkills } = userState;
    const unlockedSet = new Set(unlockedSkills);

    return (
        <div className="bg-brand-surface-light dark:bg-brand-surface rounded-xl p-6 shadow-lg">
            <div className="text-center mb-6">
                <h3 className="text-xl font-bold text-brand-text-primary-light dark:text-brand-text-primary">Árbol de Habilidades</h3>
                <p className="text-brand-text-secondary-light dark:text-brand-text-secondary text-sm mt-1">
                    Puntos de Habilidad Disponibles: <span className="font-bold text-2xl text-brand-accent-light dark:text-brand-accent">{skillPoints}</span>
                </p>
            </div>

            <div className="space-y-6">
                {SKILL_TREE.categories.map(category => (
                    <div key={category.name}>
                        <h4 className="text-lg font-semibold mb-3 text-brand-primary-light dark:text-brand-primary">{category.name}</h4>
                        <div className="space-y-3">
                            {category.skills.map(skill => {
                                const isUnlocked = unlockedSet.has(skill.id);
                                const canUnlock = skillPoints >= skill.cost && (!skill.requires || unlockedSet.has(skill.requires));
                                
                                let statusClasses = 'border-gray-300 dark:border-gray-600';
                                if (isUnlocked) statusClasses = 'border-brand-accent-light dark:border-brand-accent shadow-lg shadow-brand-accent/20';
                                else if (canUnlock) statusClasses = 'border-brand-primary-light dark:border-brand-primary opacity-90';

                                return (
                                    <div key={skill.id} className={`bg-brand-bg-light dark:bg-brand-bg p-4 rounded-lg border-l-4 transition-all ${statusClasses}`}>
                                        <div className="flex justify-between items-start">
                                            <div>
                                                <h5 className="font-bold text-brand-text-primary-light dark:text-brand-text-primary">{skill.name}</h5>
                                                <p className="text-sm text-brand-text-secondary-light dark:text-brand-text-secondary mt-1">{skill.description}</p>
                                                {skill.requires && <p className="text-xs text-brand-text-secondary-light dark:text-brand-text-secondary mt-1 italic">Requiere: {SKILL_TREE.categories.flatMap(c => c.skills).find(s => s.id === skill.requires)?.name}</p>}
                                            </div>
                                            <div className="text-right ml-4 flex-shrink-0">
                                                {isUnlocked ? (
                                                    <span className="text-sm font-bold text-green-500 dark:text-green-400 px-3 py-1 bg-green-500/10 rounded-full">Desbloqueado</span>
                                                ) : (
                                                    <button 
                                                        onClick={() => onUnlockSkill(skill.id)}
                                                        disabled={!canUnlock}
                                                        className="bg-brand-primary-light dark:bg-brand-primary hover:bg-brand-primary-light/80 dark:hover:bg-brand-primary/80 text-white font-bold py-2 px-4 rounded-lg transition-colors text-sm disabled:bg-gray-400 dark:disabled:bg-gray-600 disabled:cursor-not-allowed"
                                                    >
                                                        Coste: {skill.cost}
                                                    </button>
                                                )}
                                            </div>
                                        </div>
                                    </div>
                                );
                            })}
                        </div>
                    </div>
                ))}
            </div>
        </div>
    );
};

export default SkillTree;