
import React, { useState } from 'react';
import { CheckinData, DailyTask, UserGoals, AppView, Action } from '../types';
import { getCheckinSuggestions } from '../services/geminiService';

interface CheckinCheckoutProps {
    userGoals: UserGoals;
    hasCheckedIn: boolean;
    dailyXp: number;
    dailyTasks: DailyTask[];
    negativeActions: Action[];
    onCheckin: (data: CheckinData) => void;
    onCheckout: (reflection: string) => Promise<void>;
    onTaskToggle: (description: string, event: React.MouseEvent) => void;
    onPenalty: (action: Action, event: React.MouseEvent) => void;
    onNavigate: (view: AppView) => void;
}

const CheckinForm: React.FC<{ onCheckin: (data: CheckinData), userGoals: UserGoals }> = ({ onCheckin, userGoals }) => {
    const [checkinData, setCheckinData] = useState<Omit<CheckinData, 'checkinTime'>>({ priorities: '', status: '', dailyGoal: '', miniMission: '' });
    const [isSuggesting, setIsSuggesting] = useState(false);

    const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
        const { name, value } = e.target;
        setCheckinData(prev => ({ ...prev, [name]: value }));
    };

    const handleCheckinSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        const fullCheckinData: CheckinData = {
            ...checkinData,
            checkinTime: new Date().toTimeString().substring(0, 5) // "HH:MM"
        };
        onCheckin(fullCheckinData);
    };
    
    const handleSuggestion = async () => {
        setIsSuggesting(true);
        try {
            const suggestions = await getCheckinSuggestions(userGoals);
            setCheckinData(prev => ({ ...prev, ...suggestions }));
        } catch (error) {
            console.error("Failed to get suggestions", error);
            alert("No se pudieron obtener las sugerencias de la IA. Inténtalo de nuevo.");
        } finally {
            setIsSuggesting(false);
        }
    };

    return (
        <div className="bg-brand-surface-light dark:bg-brand-surface rounded-xl p-6 shadow-lg" data-tutorial-id="checkin-step">
            <div className="flex justify-between items-center mb-4">
                <h3 className="text-xl font-bold text-brand-accent-light dark:text-brand-accent">Check-in Diario</h3>
                <button onClick={handleSuggestion} disabled={isSuggesting} className="flex items-center gap-2 text-sm bg-brand-primary-light/10 dark:bg-brand-primary/20 hover:bg-brand-primary-light/20 dark:hover:bg-brand-primary/40 text-brand-accent-light dark:text-brand-accent font-semibold py-1 px-3 rounded-lg transition-colors disabled:opacity-50">
                    {isSuggesting ? <div className="w-4 h-4 border-2 border-brand-accent-light dark:border-brand-accent border-t-transparent rounded-full animate-spin"></div> : 
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z" /></svg>}
                    Sugerir con IA
                </button>
            </div>
            <form onSubmit={handleCheckinSubmit} className="space-y-4">
                 <div>
                    <label htmlFor="priorities" className="block text-sm font-medium text-brand-text-secondary-light dark:text-brand-text-secondary mb-1">Prioridades (3 tareas clave)</label>
                    <textarea id="priorities" name="priorities" value={checkinData.priorities} onChange={handleInputChange} rows={3} required className="w-full bg-brand-bg-light dark:bg-brand-bg rounded-md border-gray-300 dark:border-brand-surface focus:ring-brand-primary-light dark:focus:ring-brand-primary focus:border-brand-primary-light dark:focus:border-brand-primary text-sm p-2"></textarea>
                </div>
                <div>
                    <label htmlFor="status" className="block text-sm font-medium text-brand-text-secondary-light dark:text-brand-text-secondary mb-1">Estado (energía, humor, foco)</label>
                    <input type="text" id="status" name="status" value={checkinData.status} onChange={handleInputChange} required className="w-full bg-brand-bg-light dark:bg-brand-bg rounded-md border-gray-300 dark:border-brand-surface focus:ring-brand-primary-light dark:focus:ring-brand-primary focus:border-brand-primary-light dark:focus:border-brand-primary text-sm p-2" />
                </div>
                <div>
                    <label htmlFor="dailyGoal" className="block text-sm font-medium text-brand-text-secondary-light dark:text-brand-text-secondary mb-1">Meta del día</label>
                    <input type="text" id="dailyGoal" name="dailyGoal" value={checkinData.dailyGoal} onChange={handleInputChange} required className="w-full bg-brand-bg-light dark:bg-brand-bg rounded-md border-gray-300 dark:border-brand-surface focus:ring-brand-primary-light dark:focus:ring-brand-primary focus:border-brand-primary-light dark:focus:border-brand-primary text-sm p-2" />
                </div>
                <div>
                    <label htmlFor="miniMission" className="block text-sm font-medium text-brand-text-secondary-light dark:text-brand-text-secondary mb-1">Mini misión</label>
                    <input type="text" id="miniMission" name="miniMission" value={checkinData.miniMission} onChange={handleInputChange} required className="w-full bg-brand-bg-light dark:bg-brand-bg rounded-md border-gray-300 dark:border-brand-surface focus:ring-brand-primary-light dark:focus:ring-brand-primary focus:border-brand-primary-light dark:focus:border-brand-primary text-sm p-2" />
                </div>
                <button type="submit" className="w-full bg-brand-primary-light dark:bg-brand-primary hover:bg-brand-primary-light/80 dark:hover:bg-brand-primary/80 text-white font-bold py-2 px-4 rounded-lg transition-colors duration-300">
                    Comenzar Día
                </button>
            </form>
        </div>
    );
};

const DailyMissionControl: React.FC<Omit<CheckinCheckoutProps, 'hasCheckedIn' | 'userGoals' | 'onCheckin'>> = ({ dailyXp, dailyTasks, negativeActions, onCheckout, onTaskToggle, onPenalty, onNavigate }) => {
    const [reflection, setReflection] = useState('');
    const [isCheckingOut, setIsCheckingOut] = useState(false);

    const handleCheckoutSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setIsCheckingOut(true);
        await onCheckout(reflection);
        setReflection('');
        setIsCheckingOut(false);
    };
    
    return (
        <div className="bg-brand-surface-light dark:bg-brand-surface rounded-xl p-6 shadow-lg">
            <h3 className="text-xl font-bold mb-4 text-brand-secondary-light dark:text-brand-secondary">Control de Misión Diario</h3>
            <div className="text-center bg-brand-bg-light dark:bg-brand-bg p-4 rounded-lg mb-4">
                <p className="text-brand-text-secondary-light dark:text-brand-text-secondary">XP Ganado Hoy</p>
                <p className={`text-3xl font-bold ${dailyXp >= 0 ? 'text-green-500' : 'text-red-500'}`}>{dailyXp > 0 ? '+' : ''}{dailyXp}</p>
            </div>
            
            <div className="relative bg-brand-bg-light/50 dark:bg-brand-bg/50 border border-brand-primary-light/10 dark:border-brand-primary/10 p-2 rounded-lg text-center text-xs italic text-brand-text-secondary-light dark:text-brand-text-secondary mb-4 reminder-bubble">
                "Responde con sinceridad, al único que mientes es a ti mismo."
            </div>

            <div className="mb-6">
                 <div className="flex justify-between items-center mb-2">
                    <h4 className="font-semibold text-brand-text-primary-light dark:text-brand-text-primary">Acciones del Día</h4>
                    <button onClick={() => onNavigate('ACTIONS')} className="text-sm text-brand-accent-light dark:text-brand-accent hover:underline">Editar Acciones</button>
                 </div>
                 <div className="space-y-2 max-h-60 overflow-y-auto pr-2">
                    {dailyTasks.map(task => (
                        <label key={task.description} htmlFor={task.description} className={`flex items-center p-3 rounded-lg cursor-pointer transition-colors duration-200 ${task.completed ? 'bg-green-500/10' : 'bg-brand-bg-light dark:bg-brand-bg hover:bg-brand-primary-light/5 dark:hover:bg-brand-primary/10'}`}>
                             <input
                                id={task.description}
                                type="checkbox"
                                checked={task.completed}
                                onClick={(e) => onTaskToggle(task.description, e)}
                                onChange={() => {}}
                                className="h-5 w-5 rounded bg-brand-bg-light dark:bg-brand-bg border-brand-text-secondary-light dark:border-brand-text-secondary text-brand-primary-light dark:text-brand-primary focus:ring-brand-primary-light dark:focus:ring-brand-primary kpi-check"
                            />
                            <div className="ml-3 flex-grow text-sm">
                                <span className={`font-medium ${task.completed ? 'text-brand-text-secondary-light dark:text-brand-text-secondary line-through' : 'text-brand-text-primary-light dark:text-brand-text-primary'}`}>{task.description}</span>
                            </div>
                            <span className={`font-bold text-sm p-1 rounded ${task.completed ? 'text-green-500/50' : 'text-green-600 dark:text-green-400'}`}>
                                +{task.xp} XP
                            </span>
                        </label>
                    ))}
                 </div>
            </div>
            
            <div className="mb-6">
                <h4 className="font-semibold text-brand-text-primary-light dark:text-brand-text-primary mb-2">Penalizaciones</h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    {negativeActions.map(action => (
                         <button
                            key={action.description}
                            onClick={(e) => onPenalty(action, e)}
                            className="w-full text-left p-2 rounded-lg flex justify-between items-center transition-transform duration-200 bg-red-500/10 text-red-700 dark:text-red-400 hover:bg-red-500/20 hover:scale-105"
                        >
                            <span className="text-sm">{action.description}</span>
                            <span className="font-bold text-sm">{action.xp} XP</span>
                        </button>
                    ))}
                </div>
            </div>

            <form onSubmit={handleCheckoutSubmit} className="space-y-4 border-t border-gray-200 dark:border-brand-primary/20 pt-4">
                 <div>
                    <label htmlFor="reflection" className="block text-sm font-medium text-brand-text-secondary-light dark:text-brand-text-secondary mb-1">Reflexión (una línea del día)</label>
                    <textarea id="reflection" name="reflection" value={reflection} onChange={(e) => setReflection(e.target.value)} rows={2} required className="w-full bg-brand-bg-light dark:bg-brand-bg rounded-md border-gray-300 dark:border-brand-surface focus:ring-brand-secondary-light dark:focus:ring-brand-secondary focus:border-brand-secondary-light dark:focus:border-brand-secondary text-sm p-2"></textarea>
                </div>
                <button type="submit" disabled={isCheckingOut} className="w-full bg-brand-secondary-light dark:bg-brand-secondary hover:bg-brand-secondary-light/80 dark:hover:bg-brand-secondary/80 text-white font-bold py-2 px-4 rounded-lg transition-colors duration-300 flex items-center justify-center disabled:bg-gray-400 dark:disabled:bg-gray-600">
                    {isCheckingOut && <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin mr-2"></div>}
                    {isCheckingOut ? 'Analizando...' : 'Finalizar Día'}
                </button>
            </form>
        </div>
    );
};

const CheckinCheckout: React.FC<CheckinCheckoutProps> = (props) => {
    if (!props.hasCheckedIn) {
        return <CheckinForm onCheckin={props.onCheckin} userGoals={props.userGoals} />;
    }
    const { onCheckin, ...missionProps } = props;
    return <DailyMissionControl {...missionProps} />;
};

export default CheckinCheckout;