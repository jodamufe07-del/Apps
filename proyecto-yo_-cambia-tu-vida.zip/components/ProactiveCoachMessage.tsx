
import React from 'react';

interface ProactiveCoachMessageProps {
    message: string;
    onDismiss: () => void;
    onNavigate: () => void;
}

const ProactiveCoachMessage: React.FC<ProactiveCoachMessageProps> = ({ message, onDismiss, onNavigate }) => {
    
    const handleNavigate = () => {
        onNavigate();
        onDismiss();
    };

    return (
        <div className="mt-6 bg-brand-surface-light dark:bg-brand-surface border border-brand-accent-light/50 dark:border-brand-accent/50 rounded-lg p-4 animate-[toast-in_0.5s_ease-out_forwards]">
            <div className="flex items-start gap-4">
                <div className="flex-shrink-0 w-10 h-10 rounded-full bg-brand-primary-light dark:bg-brand-primary flex items-center justify-center shadow-md">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8.228 9c.549-1.165 2.03-2 3.772-2 2.21 0 4 1.343 4 3 0 1.4-1.278 2.575-3.006 2.907-.542.104-.994.54-.994 1.093m0 3h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                </div>
                <div className="flex-grow">
                    <h4 className="font-bold text-brand-accent-light dark:text-brand-accent">Un mensaje de tu Coach IA</h4>
                    <p className="text-sm text-brand-text-secondary-light dark:text-brand-text-secondary mt-1">{message}</p>
                </div>
            </div>
            <div className="flex justify-end gap-2 mt-3">
                <button 
                    onClick={onDismiss}
                    className="text-xs font-semibold text-brand-text-secondary-light dark:text-brand-text-secondary hover:text-brand-text-primary-light dark:hover:text-white px-3 py-1 rounded-md"
                >
                    Entendido
                </button>
                <button 
                    onClick={handleNavigate}
                    className="text-xs font-semibold bg-brand-primary-light/80 dark:bg-brand-primary/80 hover:bg-brand-primary-light dark:hover:bg-brand-primary text-white px-3 py-1 rounded-md transition-colors"
                >
                    Hablar con el Coach
                </button>
            </div>
        </div>
    );
};

export default ProactiveCoachMessage;