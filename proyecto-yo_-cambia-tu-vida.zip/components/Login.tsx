
import React, { useState } from 'react';
import { UserGoals } from '../types';

interface OnboardingProps {
  onComplete: (name: string, goals: UserGoals) => void;
}

const Onboarding: React.FC<OnboardingProps> = ({ onComplete }) => {
  const [name, setName] = useState('');
  const [goals, setGoals] = useState<UserGoals>({
      objective: '',
      motivation: '',
      expectation: ''
  });
  const [isLoading, setIsLoading] = useState(false);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
      const { name, value } = e.target;
      setGoals(prev => ({...prev, [name]: value}));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (name.trim() && goals.objective.trim() && goals.motivation.trim() && goals.expectation.trim()) {
      setIsLoading(true);
      // The onComplete function now triggers the AI generation, which can take time.
      // The loading state is handled here.
      await onComplete(name.trim(), goals);
      // No need to setIsLoading(false) here as the component will unmount.
    }
  };

  if (isLoading) {
      return (
        <div className="min-h-screen bg-brand-bg flex items-center justify-center p-4">
             <div className="w-full max-w-md bg-brand-surface rounded-xl p-8 shadow-2xl text-center">
                 <div className="flex justify-center items-center mb-4">
                     <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-brand-primary"></div>
                 </div>
                 <h2 className="text-2xl font-bold text-brand-text-primary">Personalizando tu viaje...</h2>
                 <p className="text-brand-text-secondary mt-2">La IA está creando tu plan de juego único.</p>
             </div>
        </div>
      );
  }

  return (
    <div className="min-h-screen bg-brand-bg-light dark:bg-brand-bg flex items-center justify-center p-4">
      <div className="w-full max-w-md bg-brand-surface-light dark:bg-brand-surface rounded-xl p-8 shadow-2xl">
        <div className="text-center">
            <h1 className="text-3xl sm:text-4xl font-bold tracking-tight text-brand-text-primary-light dark:text-brand-text-primary">
            Bienvenido a <span className="text-brand-primary-light dark:text-brand-primary">PROYECTO YO</span>
            </h1>
            <p className="text-brand-text-secondary-light dark:text-brand-text-secondary mt-2">
            Define tu misión para comenzar la aventura.
            </p>
        </div>
        <form onSubmit={handleSubmit} className="mt-8 space-y-4">
            <div>
                 <label htmlFor="name" className="block text-sm font-medium text-brand-text-secondary-light dark:text-brand-text-secondary mb-1">Tu nombre de Héroe</label>
                 <input
                    id="name" type="text" value={name} onChange={(e) => setName(e.target.value)}
                    placeholder="¿Cómo te llamarás en esta aventura?" required
                    className="w-full bg-brand-bg-light dark:bg-brand-bg rounded-md border-gray-300 dark:border-brand-surface focus:ring-brand-primary-light dark:focus:ring-brand-primary focus:border-brand-primary-light dark:focus:border-brand-primary text-md p-2"
                />
            </div>
             <div>
                 <label htmlFor="objective" className="block text-sm font-medium text-brand-text-secondary-light dark:text-brand-text-secondary mb-1">Tu Objetivo Principal</label>
                 <textarea
                    id="objective" name="objective" value={goals.objective} onChange={handleInputChange}
                    rows={2} placeholder="Ej: Aprender a programar en 6 meses, lanzar mi proyecto personal..." required
                    className="w-full bg-brand-bg-light dark:bg-brand-bg rounded-md border-gray-300 dark:border-brand-surface focus:ring-brand-primary-light dark:focus:ring-brand-primary focus:border-brand-primary-light dark:focus:border-brand-primary text-sm p-2"
                 />
            </div>
            <div>
                 <label htmlFor="motivation" className="block text-sm font-medium text-brand-text-secondary-light dark:text-brand-text-secondary mb-1">Tu Motivación (¿Por qué?)</label>
                 <textarea
                    id="motivation" name="motivation" value={goals.motivation} onChange={handleInputChange}
                    rows={2} placeholder="Ej: Para conseguir libertad financiera, para crecer como profesional..." required
                    className="w-full bg-brand-bg-light dark:bg-brand-bg rounded-md border-gray-300 dark:border-brand-surface focus:ring-brand-primary-light dark:focus:ring-brand-primary focus:border-brand-primary-light dark:focus:border-brand-primary text-sm p-2"
                 />
            </div>
            <div>
                 <label htmlFor="expectation" className="block text-sm font-medium text-brand-text-secondary-light dark:text-brand-text-secondary mb-1">¿Qué esperas lograr?</label>
                 <textarea
                    id="expectation" name="expectation" value={goals.expectation} onChange={handleInputChange}
                    rows={2} placeholder="Ej: Construir disciplina, ser más consistente, sentirme realizado..." required
                    className="w-full bg-brand-bg-light dark:bg-brand-bg rounded-md border-gray-300 dark:border-brand-surface focus:ring-brand-primary-light dark:focus:ring-brand-primary focus:border-brand-primary-light dark:focus:border-brand-primary text-sm p-2"
                 />
            </div>
          <button
            type="submit"
            className="mt-4 w-full bg-brand-primary-light dark:bg-brand-primary hover:bg-brand-primary-light/80 dark:hover:bg-brand-primary/80 text-white font-bold py-3 px-4 rounded-lg transition-colors duration-300 text-lg"
          >
            Crear mi Plan de Juego
          </button>
        </form>
      </div>
    </div>
  );
};

export default Onboarding;