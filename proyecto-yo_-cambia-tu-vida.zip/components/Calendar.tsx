
import React, { useState, useMemo } from 'react';
import { LogEntry } from '../types';

interface CalendarProps {
    entries: LogEntry[];
}

const LogDetailModal: React.FC<{ entry: LogEntry; onClose: () => void }> = ({ entry, onClose }) => {
    const date = new Date(entry.date);
    const formattedDate = date.toLocaleDateString('es-ES', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' });
    
    return (
        <div className="fixed inset-0 bg-black/70 flex items-center justify-center z-50 p-4" onClick={onClose}>
            <div className="bg-brand-surface-light dark:bg-brand-surface rounded-xl p-6 shadow-2xl max-w-md w-full animate-[toast-in_0.3s_ease-out_forwards]" onClick={e => e.stopPropagation()}>
                <div className="flex justify-between items-center border-b border-gray-200 dark:border-brand-primary/20 pb-3 mb-4">
                    <div>
                        <h3 className="text-lg font-bold text-brand-primary-light dark:text-brand-primary">{formattedDate}</h3>
                        <p className={`text-xl font-bold ${entry.dailyXp >= 0 ? 'text-green-500' : 'text-red-500'}`}>
                            {entry.dailyXp > 0 ? '+' : ''}{entry.dailyXp} XP Ganado
                        </p>
                    </div>
                     <button onClick={onClose} className="text-brand-text-secondary-light dark:text-brand-text-secondary hover:text-brand-text-primary-light dark:hover:text-white text-2xl">&times;</button>
                </div>
                <div>
                     <p className="text-brand-accent-light dark:text-brand-accent font-semibold">Reflexión del Día:</p>
                     <p className="text-sm text-brand-text-secondary-light dark:text-brand-text-secondary italic bg-brand-bg-light dark:bg-brand-bg p-2 rounded-md mt-1">"{entry.reflection}"</p>
                </div>
                <div className="mt-4">
                    <h4 className="font-semibold text-brand-accent-light dark:text-brand-accent mb-2">Check-in de ese día:</h4>
                    <ul className="text-sm text-brand-text-secondary-light dark:text-brand-text-secondary list-disc list-inside space-y-1 bg-brand-bg-light dark:bg-brand-bg p-3 rounded-md">
                        <li><span className="font-medium text-brand-text-primary-light dark:text-brand-text-primary">Meta:</span> {entry.checkin.dailyGoal}</li>
                        <li><span className="font-medium text-brand-text-primary-light dark:text-brand-text-primary">Prioridades:</span> {entry.checkin.priorities}</li>
                        <li><span className="font-medium text-brand-text-primary-light dark:text-brand-text-primary">Estado:</span> {entry.checkin.status}</li>
                        <li><span className="font-medium text-brand-text-primary-light dark:text-brand-text-primary">Misión:</span> {entry.checkin.miniMission}</li>
                    </ul>
                </div>
            </div>
        </div>
    );
};

const Calendar: React.FC<CalendarProps> = ({ entries }) => {
    const [currentDate, setCurrentDate] = useState(new Date());
    const [selectedEntry, setSelectedEntry] = useState<LogEntry | null>(null);

    const entriesByDate = useMemo(() => {
        const map = new Map<string, LogEntry>();
        entries.forEach(entry => {
            const dateKey = new Date(entry.date).toISOString().split('T')[0];
            map.set(dateKey, entry);
        });
        return map;
    }, [entries]);

    const changeMonth = (amount: number) => {
        setCurrentDate(prev => {
            const newDate = new Date(prev);
            newDate.setMonth(newDate.getMonth() + amount);
            return newDate;
        });
    };

    const renderCalendarGrid = () => {
        const year = currentDate.getFullYear();
        const month = currentDate.getMonth();
        const firstDayOfMonth = new Date(year, month, 1).getDay();
        const daysInMonth = new Date(year, month + 1, 0).getDate();
        
        const dayOffset = (firstDayOfMonth === 0) ? 6 : firstDayOfMonth - 1;

        const days = Array.from({ length: dayOffset + daysInMonth }, (_, i) => {
            if (i < dayOffset) return null; // empty cell
            const day = i - dayOffset + 1;
            const dateKey = new Date(year, month, day).toISOString().split('T')[0];
            const entry = entriesByDate.get(dateKey);

            const isToday = new Date().toISOString().split('T')[0] === dateKey;

            let cellClasses = "h-14 flex items-center justify-center text-sm rounded-lg transition-colors ";
            if (entry) {
                cellClasses += "bg-brand-primary-light/20 dark:bg-brand-primary/20 hover:bg-brand-primary-light/40 dark:hover:bg-brand-primary/40 cursor-pointer font-bold text-brand-text-primary-light dark:text-brand-text-primary";
            } else {
                cellClasses += "text-brand-text-secondary-light/50 dark:text-brand-text-secondary/50";
            }
            if (isToday) {
                 cellClasses += " border-2 border-brand-accent-light dark:border-brand-accent";
            }

            return (
                <div key={i} className={cellClasses} onClick={() => entry && setSelectedEntry(entry)}>
                    {day}
                </div>
            );
        });

        return <div className="grid grid-cols-7 gap-2">{days}</div>;
    };

    const weekDays = ['L', 'M', 'X', 'J', 'V', 'S', 'D'];

    return (
        <div className="bg-brand-surface-light dark:bg-brand-surface rounded-xl p-6 shadow-lg">
            <div className="flex justify-between items-center mb-4">
                <button onClick={() => changeMonth(-1)} className="p-2 rounded-full hover:bg-brand-bg-light dark:hover:bg-brand-bg">&lt;</button>
                <h3 className="text-xl font-bold text-center capitalize">
                    {currentDate.toLocaleString('es-ES', { month: 'long', year: 'numeric' })}
                </h3>
                <button onClick={() => changeMonth(1)} className="p-2 rounded-full hover:bg-brand-bg-light dark:hover:bg-brand-bg">&gt;</button>
            </div>
            <div className="grid grid-cols-7 gap-2 mb-2 text-center text-brand-text-secondary-light dark:text-brand-text-secondary text-xs font-bold">
                {weekDays.map(day => <div key={day}>{day}</div>)}
            </div>
            {renderCalendarGrid()}
            
            {selectedEntry && <LogDetailModal entry={selectedEntry} onClose={() => setSelectedEntry(null)} />}
        </div>
    );
};

export default Calendar;