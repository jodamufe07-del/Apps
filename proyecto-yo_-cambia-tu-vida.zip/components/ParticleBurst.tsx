

import React, { useEffect, useMemo, useState } from 'react';

interface Particle {
    id: number;
    initialX: number;
    initialY: number;
    size: number;
}

interface ParticleBurstProps {
    xp: number;
    startX: number;
    startY: number;
    endX: number;
    endY: number;
    onEnd: () => void;
}

const ParticleBurst: React.FC<ParticleBurstProps> = ({ xp, startX, startY, endX, endY, onEnd }) => {
    const isPositive = xp > 0;
    const particleCount = Math.min(Math.ceil(Math.abs(xp) / 2), 15);
    const color = isPositive ? 'bg-green-400' : 'bg-red-500';

    const particles = useMemo(() => {
        return Array.from({ length: particleCount }).map((_, i) => {
            const angle = Math.random() * 2 * Math.PI;
            const radius = Math.random() * 30 + 10;
            return {
                id: i,
                initialX: Math.cos(angle) * radius,
                initialY: Math.sin(angle) * radius,
                size: Math.random() * 4 + 2,
            };
        });
    }, [particleCount]);
    
    const [isAnimating, setIsAnimating] = useState(false);

    useEffect(() => {
        const startAnimationTimer = setTimeout(() => {
            setIsAnimating(true);
        }, 20);

        const endAnimationTimer = setTimeout(onEnd, 1000); // Duration should match CSS transition

        return () => {
            clearTimeout(startAnimationTimer);
            clearTimeout(endAnimationTimer);
        };
    }, [onEnd]);

    return (
        <div>
            {particles.map(p => (
                <div
                    key={p.id}
                    className={`particle ${color}`}
                    style={{
                        width: `${p.size}px`,
                        height: `${p.size}px`,
                        left: `${startX + p.initialX}px`,
                        top: `${startY + p.initialY}px`,
                        transform: isAnimating 
                            ? `translate(${endX - (startX + p.initialX)}px, ${endY - (startY + p.initialY)}px) scale(0)` 
                            : 'translate(0, 0) scale(1)',
                        opacity: isAnimating ? 0 : 1,
                    }}
                />
            ))}
        </div>
    );
};

export default ParticleBurst;